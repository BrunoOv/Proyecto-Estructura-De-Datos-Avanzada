﻿namespace EditordeGrafos
{
    partial class Arboles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Arbol = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnLeer = new System.Windows.Forms.Button();
            this.Raiz = new System.Windows.Forms.Label();
            this.dato = new System.Windows.Forms.Label();
            this.EndOfFile = new System.Windows.Forms.Label();
            this.save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Numero = new System.Windows.Forms.TextBox();
            this.Insertar = new System.Windows.Forms.Button();
            this.btnAbrirBin = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Registro = new System.Windows.Forms.Label();
            this.NODO = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Arbol)).BeginInit();
            this.SuspendLayout();
            // 
            // Arbol
            // 
            this.Arbol.AllowUserToAddRows = false;
            this.Arbol.AllowUserToDeleteRows = false;
            this.Arbol.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Arbol.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11});
            this.Arbol.Location = new System.Drawing.Point(12, 81);
            this.Arbol.Name = "Arbol";
            this.Arbol.ReadOnly = true;
            this.Arbol.RowHeadersWidth = 62;
            this.Arbol.Size = new System.Drawing.Size(867, 549);
            this.Arbol.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Dir";
            this.Column1.MinimumWidth = 8;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 75;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "TIPO";
            this.Column2.MinimumWidth = 8;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 50;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Apuntador";
            this.Column3.MinimumWidth = 8;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 75;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Clave";
            this.Column4.MinimumWidth = 8;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 75;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Apuntador";
            this.Column5.MinimumWidth = 8;
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 75;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Clave";
            this.Column6.MinimumWidth = 8;
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 75;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Apuntador";
            this.Column7.MinimumWidth = 8;
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 75;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Clave";
            this.Column8.MinimumWidth = 8;
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 75;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Apuntador";
            this.Column9.MinimumWidth = 8;
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 75;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Clave";
            this.Column10.MinimumWidth = 8;
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 75;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Apuntador";
            this.Column11.MinimumWidth = 8;
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 75;
            // 
            // btnLeer
            // 
            this.btnLeer.Location = new System.Drawing.Point(318, 40);
            this.btnLeer.Name = "btnLeer";
            this.btnLeer.Size = new System.Drawing.Size(114, 23);
            this.btnLeer.TabIndex = 1;
            this.btnLeer.Text = "Cargar arbol B+ (.txt)";
            this.btnLeer.UseVisualStyleBackColor = true;
            this.btnLeer.Click += new System.EventHandler(this.carga_arbol);
            // 
            // Raiz
            // 
            this.Raiz.AutoSize = true;
            this.Raiz.Location = new System.Drawing.Point(810, 6);
            this.Raiz.Name = "Raiz";
            this.Raiz.Size = new System.Drawing.Size(0, 13);
            this.Raiz.TabIndex = 3;
            // 
            // dato
            // 
            this.dato.AutoSize = true;
            this.dato.Location = new System.Drawing.Point(807, 42);
            this.dato.Name = "dato";
            this.dato.Size = new System.Drawing.Size(0, 13);
            this.dato.TabIndex = 4;
            // 
            // EndOfFile
            // 
            this.EndOfFile.AutoSize = true;
            this.EndOfFile.Location = new System.Drawing.Point(805, 22);
            this.EndOfFile.Name = "EndOfFile";
            this.EndOfFile.Size = new System.Drawing.Size(0, 13);
            this.EndOfFile.TabIndex = 5;
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(221, 40);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(91, 23);
            this.save.TabIndex = 7;
            this.save.Text = "Guardar Arbol";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.btnGuardaBin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(763, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "EOF:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(763, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Raiz:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(763, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Dato:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 11;
            // 
            // Numero
            // 
            this.Numero.Location = new System.Drawing.Point(33, 2);
            this.Numero.Name = "Numero";
            this.Numero.Size = new System.Drawing.Size(75, 20);
            this.Numero.TabIndex = 13;
            this.Numero.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Numero_KeyDown);
            // 
            // Insertar
            // 
            this.Insertar.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.Insertar.Location = new System.Drawing.Point(114, 1);
            this.Insertar.Name = "Insertar";
            this.Insertar.Size = new System.Drawing.Size(75, 23);
            this.Insertar.TabIndex = 14;
            this.Insertar.Text = "Insertar";
            this.Insertar.UseVisualStyleBackColor = false;
            this.Insertar.Click += new System.EventHandler(this.btnInserta_Click);
            // 
            // btnAbrirBin
            // 
            this.btnAbrirBin.Location = new System.Drawing.Point(318, 3);
            this.btnAbrirBin.Name = "btnAbrirBin";
            this.btnAbrirBin.Size = new System.Drawing.Size(114, 23);
            this.btnAbrirBin.TabIndex = 16;
            this.btnAbrirBin.Text = "Cargar Arbol B+";
            this.btnAbrirBin.UseVisualStyleBackColor = true;
            this.btnAbrirBin.Click += new System.EventHandler(this.btnAbrirBin_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(582, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Nodo:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(570, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Registro:";
            // 
            // Registro
            // 
            this.Registro.AutoSize = true;
            this.Registro.Location = new System.Drawing.Point(626, 25);
            this.Registro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Registro.Name = "Registro";
            this.Registro.Size = new System.Drawing.Size(0, 13);
            this.Registro.TabIndex = 19;
            // 
            // NODO
            // 
            this.NODO.AutoSize = true;
            this.NODO.Location = new System.Drawing.Point(626, 9);
            this.NODO.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.NODO.Name = "NODO";
            this.NODO.Size = new System.Drawing.Size(0, 13);
            this.NODO.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 13);
            this.label7.TabIndex = 21;
            this.label7.Text = "ID";
            // 
            // Arboles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(879, 641);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.NODO);
            this.Controls.Add(this.Registro);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnAbrirBin);
            this.Controls.Add(this.Insertar);
            this.Controls.Add(this.Numero);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.save);
            this.Controls.Add(this.EndOfFile);
            this.Controls.Add(this.dato);
            this.Controls.Add(this.Raiz);
            this.Controls.Add(this.btnLeer);
            this.Controls.Add(this.Arbol);
            this.Name = "Arboles";
            this.Text = "Arboles";
            ((System.ComponentModel.ISupportInitialize)(this.Arbol)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Arbol;
        private System.Windows.Forms.Button btnLeer;

        private System.Windows.Forms.Label Raiz;
        private System.Windows.Forms.Label dato;

        private System.Windows.Forms.Label EndOfFile;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Numero;
        private System.Windows.Forms.Button Insertar;
        private System.Windows.Forms.Button btnAbrirBin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Registro;
        private System.Windows.Forms.Label NODO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.Label label7;
    }
}