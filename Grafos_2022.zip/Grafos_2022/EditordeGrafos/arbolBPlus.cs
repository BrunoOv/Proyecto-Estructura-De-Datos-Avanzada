﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditordeGrafos
{
    public class arbolBPlus
    {
        public long num;
        public long dir_sig;
        public string Tipo;
        public long dir;

        public arbolBPlus(int elementos)
        {
            this.num = elementos;
            this.dir_sig = -1;
            Tipo = "..........";
        }
    }
}
