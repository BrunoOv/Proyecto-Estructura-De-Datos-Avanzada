﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EditordeGrafos
{
    /*Encabezado
     * NumeroDeCubetas - NumeroDeCubetas - TamañoDeRegistro - DireccionCubetasVacias */
    public partial class Hash : Form
    {
        int Cubetas;
        int Registros;
        int tamañoRegistro=150;
        public string archivo = null;
        string cadenaDeCeros = new string('0', 145);
        public List<int> numeros= new List<int>();
        public List<int> dentroTabla = new List<int>();
        private BinaryWriter writer;
        private BinaryReader reader;
        //mod es nCubetas
        public void HashWrite()
        {
            try
            {
                writer = new BinaryWriter(File.OpenWrite(archivo));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        public void HashReader()
        {
            try
            {
                reader = new BinaryReader(File.OpenRead(archivo));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        public Hash()
        {
            InitializeComponent();
        }

        private void nuevaTabla_Click(object sender, EventArgs e)
        {
            tamañoCubetas.Text = string.Empty;
            tamañoTabla.Text = string.Empty;
            dentroTabla.Clear();
            limpia_Tablas();
            if (nCubetas.Text != "" && nRegistros.Text != "" && nCubetas.Enabled == true) {

                SaveFileDialog sav = new SaveFileDialog
                {
                    Filter = "Bin Files (*.bin)|*.bin|All files (*.*)|*.*",
                    InitialDirectory = Application.StartupPath + "\\ProyectosGrafo"
                };

                if (sav.ShowDialog() == DialogResult.OK)
                {
                    archivo = sav.FileName;

                    // Si el archivo ya existe, elimina su contenido
                    if (File.Exists(archivo))
                    {
                        File.WriteAllText(archivo, string.Empty);
                    }
                }
                if (int.TryParse(nCubetas.Text, out int Cubetas) && int.TryParse(nRegistros.Text, out int Registros))
                {

                    HashWrite();
                    writer.Seek(0, SeekOrigin.Begin);
                    writer.Write(Cubetas);//NCubetas
                    writer.Write(Registros);//NRegistros
                    writer.Write(tamañoRegistro);//TamañoDeRegistro
                    writer.Write((long)0);//CubetaVacia
                    for (int i=0; i<Cubetas;i++)//direcciones a cubetas
                    {
                        writer.Write((long)-1);
                    }
                    for (int i = 0; i < Registros; i++)
                    {
                        cubetas.Columns.Add($"R{i + 1}", $"R{i + 1}");
                    }
                    nCubetas.Enabled = false;
                    nRegistros.Enabled = false;

                    writer.Flush();
                    writer.Close();
                    actualizaTablas();
                }
            }
            else
            {
                MessageBox.Show("Por favor complete los apartados de:\nNumero de direcciones\nNumero de cubetas");
                nCubetas.Enabled = true;
                nRegistros.Enabled = true;
                nCubetas.Text = "";
                nRegistros.Text = "";
            }
        }
        public void actualizaTablas()
        {
            HashReader();
            cubetas.Rows.Clear();
            direccionesCubeta.Rows.Clear();
            int cubetasUsadas=0;
            reader.BaseStream.Seek(0, SeekOrigin.Begin);
            Cubetas=reader.ReadInt32();//cubetas
            Registros = reader.ReadInt32();//registrosporcubeta
            nCubetas.Text = Cubetas.ToString();
            nRegistros.Text= Registros.ToString();
            reader.ReadInt32();//tamañodearchivos
            reader.ReadUInt64();//sig_cubeta
            for (int i = 0; i < Cubetas; i++)//direccionDeCubetas
            {
                long aux = reader.ReadInt64();
                DataGridViewRow row = new DataGridViewRow();
                row.Cells.Add(new DataGridViewTextBoxCell { Value = i });
                row.Cells.Add(new DataGridViewTextBoxCell { Value = aux });
                if (aux!=-1)
                {
                    cubetasUsadas++;
                }
                direccionesCubeta.Rows.Add(row);   
            }
            tamañoTabla.Text = reader.BaseStream.Position.ToString();
            //cargamos cubetas
            for (int i = 0; i < cubetasUsadas; i++)
            {
                long dir=reader.ReadInt64();
                int oc=reader.ReadInt32();
                long dir_sig=reader.ReadInt64();
                DataGridViewRow f = new DataGridViewRow();
                f.Cells.Add(new DataGridViewTextBoxCell {Value= dir});
                f.Cells.Add(new DataGridViewTextBoxCell { Value = oc });
                f.Cells.Add(new DataGridViewTextBoxCell { Value = dir_sig });
                for (int j = 0; j < Registros; j++)
                {
                    int numero = reader.ReadInt32();
                    dentroTabla.Add(numero);
                    f.Cells.Add(new DataGridViewTextBoxCell { Value = numero});
                    reader.ReadString();
                }
                cubetas.Rows.Add(f);
            }
            EOF.Text = reader.BaseStream.Position.ToString();
            tamañoCubetas.Text =(int.Parse(EOF.Text)-int.Parse(tamañoTabla.Text)).ToString();
            reader.Close();
        }
        private void guardarTabla_Click(object sender, EventArgs e)
        {
            SaveFileDialog sav = new SaveFileDialog
            {
                Filter = "Bin Files (*.bin)|*.bin|All files (*.*)|*.*",
                InitialDirectory = Application.StartupPath + "\\ProyectosGrafo"
            };

            if (sav.ShowDialog() == DialogResult.OK)
            {
                archivo = sav.FileName;
            }
        }

        private void cargaTablaArchivo_Click(object sender, EventArgs e)
        {
            OpenFileDialog sav = new OpenFileDialog
            {
                Filter = "Bin Files (*.bin)|*.bin|All files (*.*)|*.*",
                InitialDirectory = Application.StartupPath + "\\ProyectosGrafo"
            };
            if (sav.ShowDialog() == DialogResult.OK)
            {
                archivo = sav.FileName;
            }
            HashReader();
            reader.BaseStream.Seek(4, SeekOrigin.Begin);
            int re=reader.ReadInt32();
            for (int i = 0; i < re; i++)
            {
                cubetas.Columns.Add($"R{i + 1}", $"R{i + 1}");
            }
            reader.Close();
            nRegistros.Text="";
            nCubetas.Text = "";
            nRegistros.Enabled = false;
            nCubetas.Enabled= false;
            actualizaTablas();
        }

        private void Insertar_Click(object sender, EventArgs e)
        {
            inserta();
        }
        public void inserta()
        {
            if (datoAInsertar.Text != "")
            {
                if (int.TryParse(datoAInsertar.Text, out int valor))
                {
                    if (!dentroTabla.Contains(valor))
                    {
                        int cubetaDestino = valor % Cubetas;
                        MessageBox.Show("Le toca la cubeta: "+cubetaDestino.ToString());
                        if (cubetaDestino < direccionesCubeta.Rows.Count)
                        {

                            long direccion = Convert.ToInt64(direccionesCubeta.Rows[cubetaDestino].Cells[1].Value);
                            if (direccion == -1)
                            {
                                HashWrite();
                                writer.Seek(0, SeekOrigin.End);
                                long dirlocal = writer.BaseStream.Position;

                                writer.Seek(20 + (8 * cubetaDestino), SeekOrigin.Begin);
                                writer.Write(dirlocal + 1);

                                // Quiere decir que no se ha usado la cubeta
                                writer.Seek((int)dirlocal, SeekOrigin.Begin);
                                writer.Write(dirlocal + 1);
                                writer.Write(1);
                                writer.Write((long)0);
                                writer.Write(valor);
                                writer.Write(cadenaDeCeros);
                                for (int i = 0; i < Registros - 1; i++)
                                {
                                    writer.Write(0);
                                    writer.Write(cadenaDeCeros);
                                }

                                writer.Flush();
                                writer.Close();
                            }
                            else
                            {
                                HashReader();
                                reader.BaseStream.Seek(direccion - 1, SeekOrigin.Begin);
                                reader.ReadInt64();
                                int ocupados = reader.ReadInt32();
                                reader.ReadInt64();
                                numeros.Clear();
                                for (int i = 1; i < Registros; i++)
                                {
                                    numeros.Add(reader.ReadInt32());
                                    reader.ReadString();
                                }
                                numeros.Add(valor);
                                numeros.RemoveAll(x => x == 0);
                                numeros.Sort();
                                reader.Close();
                                if (ocupados != Registros)
                                {
                                    HashWrite();
                                    writer.Seek((int)direccion - 1, SeekOrigin.Begin);
                                    writer.Write(direccion);
                                    writer.Write(ocupados + 1);
                                    writer.Write((long)0);
                                    for (int i = 0; i < numeros.Count; i++)
                                    {
                                        writer.Write(numeros[i]);
                                        writer.Write(cadenaDeCeros);
                                    }
                                    for (int i = 0; i < Registros-numeros.Count; i++)
                                    {
                                        writer.Write(0);
                                        writer.Write(cadenaDeCeros);
                                    }
                                    writer.Flush();
                                    writer.Close();
                                }
                                else
                                {
                                    MessageBox.Show("La cubeta esta llena");
                                }
                            }
                            datoAInsertar.Text = "";
                        }

                    }
                    else
                    {
                        MessageBox.Show("Ya se encuentra en alguna cubeta el numero : "+valor.ToString());
                        datoAInsertar.Text = "";
                    }
                }
            }
            else
            {
                MessageBox.Show("Valor no valido");
            }
            actualizaTablas();
        }
        public void limpia_Tablas()
        {
            direccionesCubeta.Rows.Clear();
            cubetas.Rows.Clear();

            // Establecer las nuevas columnas para direccionesCubeta
            direccionesCubeta.Columns.Clear();
            direccionesCubeta.Columns.Add("nCubeta", "nCubeta");
            direccionesCubeta.Columns.Add("Dirección", "Dirección");

            // Establecer las nuevas columnas para cubetas
            cubetas.Columns.Clear();
            cubetas.Columns.Add("Dirección", "Dirección");
            cubetas.Columns.Add("Ocupados", "Ocupados");
            cubetas.Columns.Add("Sig_Cubeta", "Sig_Cubeta");
        }

        private void txtInserta_Click(object sender, EventArgs e)
        {
            if (archivo != null)
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Archivos de Texto (*.txt)|*.txt";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string archivoPath = openFileDialog.FileName;

                    try
                    {
                        string contenido = File.ReadAllText(archivoPath);
                        string[] numerosComoCadenas = contenido.Split(',');

                        foreach (string numeroComoCadena in numerosComoCadenas)
                        {
                            if (int.TryParse(numeroComoCadena, out int numero))
                            {
                                datoAInsertar.Text = numero.ToString();
                                inserta();
                            }
                            else
                            {
                                Console.WriteLine("Pasa algo raro");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No a creado un archivo");
            }
        }

        private void cubetas_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
