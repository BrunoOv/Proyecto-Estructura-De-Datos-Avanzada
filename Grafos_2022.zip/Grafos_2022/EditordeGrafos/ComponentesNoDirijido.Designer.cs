﻿namespace EditordeGrafos
{
    partial class ComponentesNoDirijido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Inicio = new System.Windows.Forms.Button();
            this.ComponentesLabel = new System.Windows.Forms.Label();
            this.RecorridoPrintf = new System.Windows.Forms.Label();
            this.LargoCiclo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Inicio
            // 
            this.Inicio.BackColor = System.Drawing.Color.IndianRed;
            this.Inicio.ForeColor = System.Drawing.Color.DarkMagenta;
            this.Inicio.Location = new System.Drawing.Point(162, 12);
            this.Inicio.Name = "Inicio";
            this.Inicio.Size = new System.Drawing.Size(85, 48);
            this.Inicio.TabIndex = 0;
            this.Inicio.Text = "Muesta Componentes Conexos";
            this.Inicio.UseVisualStyleBackColor = false;
            this.Inicio.Click += new System.EventHandler(this.Inicio_Click);
            // 
            // ComponentesLabel
            // 
            this.ComponentesLabel.AutoSize = true;
            this.ComponentesLabel.Location = new System.Drawing.Point(142, 127);
            this.ComponentesLabel.Name = "ComponentesLabel";
            this.ComponentesLabel.Size = new System.Drawing.Size(19, 13);
            this.ComponentesLabel.TabIndex = 2;
            this.ComponentesLabel.Text = "....";
            // 
            // RecorridoPrintf
            // 
            this.RecorridoPrintf.AutoSize = true;
            this.RecorridoPrintf.BackColor = System.Drawing.Color.LightSalmon;
            this.RecorridoPrintf.Location = new System.Drawing.Point(142, 77);
            this.RecorridoPrintf.Name = "RecorridoPrintf";
            this.RecorridoPrintf.Size = new System.Drawing.Size(40, 13);
            this.RecorridoPrintf.TabIndex = 3;
            this.RecorridoPrintf.Text = "Raiz ( )";
            // 
            // LargoCiclo
            // 
            this.LargoCiclo.AutoSize = true;
            this.LargoCiclo.BackColor = System.Drawing.Color.LightSalmon;
            this.LargoCiclo.Location = new System.Drawing.Point(142, 100);
            this.LargoCiclo.Name = "LargoCiclo";
            this.LargoCiclo.Size = new System.Drawing.Size(86, 13);
            this.LargoCiclo.TabIndex = 4;
            this.LargoCiclo.Text = "Ciclo Mas Largo:";
            // 
            // ComponentesNoDirijido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 450);
            this.Controls.Add(this.LargoCiclo);
            this.Controls.Add(this.RecorridoPrintf);
            this.Controls.Add(this.ComponentesLabel);
            this.Controls.Add(this.Inicio);
            this.Name = "ComponentesNoDirijido";
            this.Text = "ComponentesNoDirijido";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Inicio;
        private System.Windows.Forms.Label ComponentesLabel;
        private System.Windows.Forms.Label RecorridoPrintf;
        private System.Windows.Forms.Label LargoCiclo;
    }
}