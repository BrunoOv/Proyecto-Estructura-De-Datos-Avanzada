﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditordeGrafos
{
    public class datosArbolB
    {
        public List<long> Dir { get; set; }
        public List<string> T { get; set; }
        public List<long> AP { get; set; }
        public List<int> CB { get; set; }
        public List<long> AP2 { get; set; }
        public List<int> CB2 { get; set; }
        public List<long> AP3 { get; set; }
        public List<int> CB3 { get; set; }
        public List<long> AP4 { get; set; }
        public List<int> CB4 { get; set; }
        public List<long> AP5 { get; set; }


        public datosArbolB()
        {
            Dir = new List<long>();
            T = new List<string>();
            AP = new List<long>();
            CB = new List<int>();
            AP2 = new List<long>();
            CB2 = new List<int>();
            AP3 = new List<long>();
            CB3 = new List<int>();
            AP4 = new List<long>();
            CB4 = new List<int>();
            AP5 = new List<long>();
        }
    }
}
