﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace EditordeGrafos
{
    public partial class ComponentesNoDirijido : Form
    {
        int contador = 0;
        int cicloGrande=0;
        Graph grafo = null;
        List<NodeP> visitados = new List<NodeP>();
        List<NodeP> caminoActual = new List<NodeP>();
        List<NodeP> caminoMasLargo=new List<NodeP>();

        public ComponentesNoDirijido(Graph graph)
        {
            InitializeComponent();
            grafo = graph;
        }

        private void Inicio_Click(object sender, EventArgs e)
        {
            ComponentesLabel.Text = "";
            RecorridoPrintf.Text = "";
            visitados.Clear();

            NodeP nodoInicial = NodoGrande(grafo); // Nodo con más adyacencias
            RecorridoPrintf.Text += "Raiz ( " + nodoInicial.Name + " ) ";
            BuscaCiclosDesdeNodo(nodoInicial);
            //luego los demas que quedan 
            foreach (NodeP nodo in grafo)
            {
                if (!visitados.Contains(nodo))
                {
                    caminoActual.Clear();
                    DFS(nodo, null);
                }
            }
            foreach (NodeP nodo in caminoMasLargo)
            {

                LargoCiclo.Text += nodo.Name + " ";
            }
        }

        public NodeP NodoGrande(Graph grafo)
        {
            NodeP nodoMayorAdyacencias = null;
            int maxAdyacencias = -1;

            foreach (NodeP nodo in grafo)
            {
                int adyacenciasActual = nodo.relations.Count;

                if (adyacenciasActual > maxAdyacencias)
                {
                    maxAdyacencias = adyacenciasActual;
                    nodoMayorAdyacencias = nodo;
                }
            }
            return nodoMayorAdyacencias;
        }

        private void BuscaCiclosDesdeNodo(NodeP nodo)
        {
            caminoActual.Clear();
            DFS(nodo, null);
        }

        private void DFS(NodeP nodo, NodeP padre)
        {
            int bin = 0;
            visitados.Add(nodo);
            caminoActual.Add(nodo);
            if (!RecorridoPrintf.Text.Contains(nodo.Name))
            {
                RecorridoPrintf.Text += " " + nodo.Name + " ";
            }
            nodo.OrdenaRelacion(nodo);
            foreach (NodeR relacion in nodo.relations)
            {
                NodeP nodoVecino = relacion.Up;

                if (nodoVecino != padre)
                {
                    if (caminoActual.Contains(nodoVecino))//se encontro un ciclo
                    {
                        ImprimeCiclo(nodoVecino);
                    }
                    else if (!visitados.Contains(nodoVecino))
                    {
                        DFS(nodoVecino, nodo);
                        bin++;
                    }
                }
            }
            if (bin > 2)//si el nodo tiene mas de 2 hijos tns no es binario
            {
                MessageBox.Show("ARBOL GENERADO NO BINARIO\nNo se puede procesar");
                this.Close();
            }
            caminoActual.Remove(nodo);
        }

        private void ImprimeCiclo(NodeP nodoCiclo)
        {
            ComponentesLabel.Text += contador + 1 + ". ";
            contador++;
            int indiceInicio = caminoActual.IndexOf(nodoCiclo);
            int indiceFin = caminoActual.Count - 1;

            if (indiceInicio != -1)
            {
                List<NodeP> ciclo = caminoActual.GetRange(indiceInicio, indiceFin - indiceInicio + 1);
              
                foreach (NodeP nodo in ciclo)
                {
                    ComponentesLabel.Text += nodo.Name + " ";
                }
                ComponentesLabel.Text += nodoCiclo.Name + "\n\n";
                if (cicloGrande < ciclo.Count)//de los ciclos vemos cual es mas grande
                {
                    cicloGrande = ciclo.Count;
                    caminoMasLargo = ciclo;    //lo guardamos en caminoMasLargo para imprimirlo cuando acabe el codigo
                    caminoMasLargo.Add(nodoCiclo);
                }
            }
        }
    }
}
