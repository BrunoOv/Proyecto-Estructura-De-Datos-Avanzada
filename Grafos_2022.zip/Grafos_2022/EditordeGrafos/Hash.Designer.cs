﻿namespace EditordeGrafos
{
    partial class Hash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Insertar = new System.Windows.Forms.Button();
            this.nuevaTabla = new System.Windows.Forms.Button();
            this.nRegistros = new System.Windows.Forms.TextBox();
            this.nCubetas = new System.Windows.Forms.TextBox();
            this.cargaTablaArchivo = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.datoAInsertar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.direccionesCubeta = new System.Windows.Forms.DataGridView();
            this.nCubeta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cubetas = new System.Windows.Forms.DataGridView();
            this.Dirección = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ocupados = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sig_Cubeta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.guardarTabla = new System.Windows.Forms.Button();
            this.EOF = new System.Windows.Forms.Label();
            this.tamañoTabla = new System.Windows.Forms.Label();
            this.tamañoCubetas = new System.Windows.Forms.Label();
            this.txtInserta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.direccionesCubeta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cubetas)).BeginInit();
            this.SuspendLayout();
            // 
            // Insertar
            // 
            this.Insertar.Location = new System.Drawing.Point(453, 40);
            this.Insertar.Name = "Insertar";
            this.Insertar.Size = new System.Drawing.Size(75, 23);
            this.Insertar.TabIndex = 0;
            this.Insertar.Text = "Inserta";
            this.Insertar.UseVisualStyleBackColor = true;
            this.Insertar.Click += new System.EventHandler(this.Insertar_Click);
            // 
            // nuevaTabla
            // 
            this.nuevaTabla.Location = new System.Drawing.Point(272, 9);
            this.nuevaTabla.Name = "nuevaTabla";
            this.nuevaTabla.Size = new System.Drawing.Size(104, 23);
            this.nuevaTabla.TabIndex = 1;
            this.nuevaTabla.Text = "Nueva Tabla";
            this.nuevaTabla.UseVisualStyleBackColor = true;
            this.nuevaTabla.Click += new System.EventHandler(this.nuevaTabla_Click);
            // 
            // nRegistros
            // 
            this.nRegistros.Location = new System.Drawing.Point(134, 45);
            this.nRegistros.Name = "nRegistros";
            this.nRegistros.Size = new System.Drawing.Size(100, 20);
            this.nRegistros.TabIndex = 2;
            // 
            // nCubetas
            // 
            this.nCubetas.Location = new System.Drawing.Point(134, 12);
            this.nCubetas.Name = "nCubetas";
            this.nCubetas.Size = new System.Drawing.Size(100, 20);
            this.nCubetas.TabIndex = 3;
            // 
            // cargaTablaArchivo
            // 
            this.cargaTablaArchivo.Location = new System.Drawing.Point(272, 62);
            this.cargaTablaArchivo.Name = "cargaTablaArchivo";
            this.cargaTablaArchivo.Size = new System.Drawing.Size(103, 23);
            this.cargaTablaArchivo.TabIndex = 4;
            this.cargaTablaArchivo.Text = "Cargar Tabla";
            this.cargaTablaArchivo.UseVisualStyleBackColor = true;
            this.cargaTablaArchivo.Click += new System.EventHandler(this.cargaTablaArchivo_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Número de Cubetas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 26);
            this.label2.TabIndex = 7;
            this.label2.Text = "Número de registros \r\npor cubetas";
            // 
            // datoAInsertar
            // 
            this.datoAInsertar.Location = new System.Drawing.Point(439, 12);
            this.datoAInsertar.Name = "datoAInsertar";
            this.datoAInsertar.Size = new System.Drawing.Size(100, 20);
            this.datoAInsertar.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(647, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Tamaño por registro : 150";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(647, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "EOF : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(647, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(10, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = " ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(647, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Tamaño Tabla : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(647, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(112, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Tamaño de Cubetas : ";
            // 
            // direccionesCubeta
            // 
            this.direccionesCubeta.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.direccionesCubeta.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nCubeta,
            this.Direccion});
            this.direccionesCubeta.Location = new System.Drawing.Point(12, 96);
            this.direccionesCubeta.Name = "direccionesCubeta";
            this.direccionesCubeta.Size = new System.Drawing.Size(244, 353);
            this.direccionesCubeta.TabIndex = 14;
            // 
            // nCubeta
            // 
            this.nCubeta.HeaderText = "nCubeta";
            this.nCubeta.Name = "nCubeta";
            // 
            // Direccion
            // 
            this.Direccion.HeaderText = "Dirección";
            this.Direccion.Name = "Direccion";
            // 
            // cubetas
            // 
            this.cubetas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cubetas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Dirección,
            this.Ocupados,
            this.Sig_Cubeta});
            this.cubetas.Location = new System.Drawing.Point(272, 96);
            this.cubetas.Name = "cubetas";
            this.cubetas.Size = new System.Drawing.Size(733, 353);
            this.cubetas.TabIndex = 15;
            this.cubetas.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.cubetas_CellContentClick);
            // 
            // Dirección
            // 
            this.Dirección.HeaderText = "Dirección";
            this.Dirección.Name = "Dirección";
            // 
            // Ocupados
            // 
            this.Ocupados.HeaderText = "Ocupados";
            this.Ocupados.Name = "Ocupados";
            // 
            // Sig_Cubeta
            // 
            this.Sig_Cubeta.HeaderText = "Sig_Cubeta";
            this.Sig_Cubeta.Name = "Sig_Cubeta";
            // 
            // guardarTabla
            // 
            this.guardarTabla.Location = new System.Drawing.Point(272, 35);
            this.guardarTabla.Name = "guardarTabla";
            this.guardarTabla.Size = new System.Drawing.Size(103, 23);
            this.guardarTabla.TabIndex = 16;
            this.guardarTabla.Text = "Guardar Tabla";
            this.guardarTabla.UseVisualStyleBackColor = true;
            this.guardarTabla.Click += new System.EventHandler(this.guardarTabla_Click);
            // 
            // EOF
            // 
            this.EOF.AutoSize = true;
            this.EOF.Location = new System.Drawing.Point(762, 22);
            this.EOF.Name = "EOF";
            this.EOF.Size = new System.Drawing.Size(13, 13);
            this.EOF.TabIndex = 17;
            this.EOF.Text = "0";
            // 
            // tamañoTabla
            // 
            this.tamañoTabla.AutoSize = true;
            this.tamañoTabla.Location = new System.Drawing.Point(762, 45);
            this.tamañoTabla.Name = "tamañoTabla";
            this.tamañoTabla.Size = new System.Drawing.Size(13, 13);
            this.tamañoTabla.TabIndex = 18;
            this.tamañoTabla.Text = "0";
            // 
            // tamañoCubetas
            // 
            this.tamañoCubetas.AutoSize = true;
            this.tamañoCubetas.Location = new System.Drawing.Point(762, 67);
            this.tamañoCubetas.Name = "tamañoCubetas";
            this.tamañoCubetas.Size = new System.Drawing.Size(13, 13);
            this.tamañoCubetas.TabIndex = 19;
            this.tamañoCubetas.Text = "0";
            // 
            // txtInserta
            // 
            this.txtInserta.Location = new System.Drawing.Point(439, 67);
            this.txtInserta.Name = "txtInserta";
            this.txtInserta.Size = new System.Drawing.Size(100, 23);
            this.txtInserta.TabIndex = 20;
            this.txtInserta.Text = "Inserta txt";
            this.txtInserta.UseVisualStyleBackColor = true;
            this.txtInserta.Click += new System.EventHandler(this.txtInserta_Click);
            // 
            // Hash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 570);
            this.Controls.Add(this.txtInserta);
            this.Controls.Add(this.tamañoCubetas);
            this.Controls.Add(this.tamañoTabla);
            this.Controls.Add(this.EOF);
            this.Controls.Add(this.guardarTabla);
            this.Controls.Add(this.cubetas);
            this.Controls.Add(this.direccionesCubeta);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.datoAInsertar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cargaTablaArchivo);
            this.Controls.Add(this.nCubetas);
            this.Controls.Add(this.nRegistros);
            this.Controls.Add(this.nuevaTabla);
            this.Controls.Add(this.Insertar);
            this.Name = "Hash";
            this.Text = "Hash";
            ((System.ComponentModel.ISupportInitialize)(this.direccionesCubeta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cubetas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Insertar;
        private System.Windows.Forms.Button nuevaTabla;
        private System.Windows.Forms.TextBox nRegistros;
        private System.Windows.Forms.TextBox nCubetas;
        private System.Windows.Forms.Button cargaTablaArchivo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox datoAInsertar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView direccionesCubeta;
        private System.Windows.Forms.DataGridView cubetas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dirección;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ocupados;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sig_Cubeta;
        private System.Windows.Forms.Button guardarTabla;
        private System.Windows.Forms.Label EOF;
        private System.Windows.Forms.Label tamañoTabla;
        private System.Windows.Forms.Label tamañoCubetas;
        private System.Windows.Forms.Button txtInserta;
        private System.Windows.Forms.DataGridViewTextBoxColumn nCubeta;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion;
    }
}