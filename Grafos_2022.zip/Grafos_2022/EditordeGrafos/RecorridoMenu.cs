﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace EditordeGrafos
{
    public partial class RecorridoMenu : Form
    {
        private Graph graphn;
        public RecorridoMenu(Graph graph)
        {
            graphn = graph;
            InitializeComponent();
            if (graph.EdgeIsDirected) {
                label1.Text = label1.Text +"Grafo Dirijido";
            }
            else 
            {
                label1.Text = label1.Text + "Grafo No Dirijido";
            }

        }
     
        private void bttAmpli_Click(object sender, EventArgs e)
        {
           RecorridoAmplitud c = new RecorridoAmplitud(graphn);
           c.ShowDialog();
        }

        private void bttProfun_Click(object sender, EventArgs e)
        {
            RecorridoProfundidad c = new RecorridoProfundidad(graphn);
            c.ShowDialog();
        }

        private void ComponenteNoDirjido_Click(object sender, EventArgs e)
        {
            ComponentesNoDirijido c = new ComponentesNoDirijido(graphn);
            c.ShowDialog();
        }

        private void Euler_Click(object sender, EventArgs e)
        {
            Euler c = new Euler(graphn);
            c.ShowDialog();
        }

        private void bttDijstra_Click(object sender, EventArgs e)
        {
            Dijkstra c = new Dijkstra(graphn);
            c.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Prim c = new Prim(graphn);
            c.ShowDialog();
        }
    }
}
