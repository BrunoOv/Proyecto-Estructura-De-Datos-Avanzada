﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace EditordeGrafos
{
    public partial class Proyecto : Form
    {
        List<string> ciudades = new List<string>();
        NodeP destino;
        NodeP raizActual;
        Graph grafo;
        Dictionary<NodeP, Tuple<string, NodeP>> DistanciayNodoAnterior = new Dictionary<NodeP, Tuple<string, NodeP>>();
        List<List<string>> vectorRelacionCambios = new List<List<string>>();
        private const string inf = "∞";
        public Proyecto(Graph graph)
        {
            InitializeComponent();
            grafo = graph;
            cargarCiudades();
            asignarnombreLabel();
        }
        public void cargarCiudades()
        {
            raizActual = grafo.First();
            ciudades = new List<string>();

            ciudades.Add("Ciudad Luminalia"); // 0
            ciudades.Add("Ciudad Plateada");  // 1
            ciudades.Add("Ciudad Celeste");   // 2
            ciudades.Add("Ciudad Carmín");    // 3
            ciudades.Add("Ciudad Azafrán");   // 4
            ciudades.Add("Ciudad Fucsia");    // 5
            ciudades.Add("Ciudad Azulona");   // 6
            ciudades.Add("Ciudad Iris");      // 7
            ciudades.Add("Ciudad Romantis");  // 8
            ciudades.Add("Ciudad Hantal");    // 9
            ciudades.Add("Ciudad Pistacho");  // 10
            ciudades.Add("Ciudad Cerezo");    // 11
            ciudades.Add("Ciudad Azuliza");   // 12
            ciudades.Add("Ciudad Pirita");    // 13
            ciudades.Add("Ciudad Olivo");     // 14
            ciudades.Add("Ciudad Trigal");    // 15
            ciudades.Add("Ciudad Endrino");   // 16
            ciudades.Add("Ciudad Orquídea");  // 17
            ciudades.Add("Ciudad Algaria");   // 18
            ciudades.Add("Ciudad Férrica");   // 19
            ciudades.Add("Ciudad Pedregal");  // 20
            ciudades.Add("Ciudad Tecnopole"); // 21
            ciudades.Add("Ciudad Puntera");   // 22
            ciudades.Add("Ciudad Relieve");   // 23
            ciudades.Add("Ciudad Cordal");    // 24
            ciudades.Add("Ciudad Yantra");    // 25
            ciudades.Add("Ciudad Domina");    // 26
            ciudades.Add("Ciudad Hiedra");    // 27
            ciudades.Add("Ciudad Reflejo");   // 28
            ciudades.Add("Ciudad Batik");     // 29
            ciudades.Add("Ciudad Nova");      // 30
            ciudades.Add("Ciudad Terracota"); // 31
            ciudades.Add("Ciudad Esperanza"); // 32
            ciudades.Add("Ciudad Romanza");   // 33
            ciudades.Add("Ciudad Mar azul");  // 34
            ciudades.Add("Ciudad Marea");     // 35
            ciudades.Add("Ciudad Jubileo");   // 36
            ciudades.Add("Ciudad Prados");    // 37
            ciudades.Add("Ciudad Lacrima");   // 38
            ciudades.Add("Ciudad Poza");      // 39
            ciudades.Add("Ciudad Plata");     // 40
            ciudades.Add("Ciudad Teselia");   // 41
            ciudades.Add("Ciudad Ocaso");     // 42
            ciudades.Add("Ciudad Suma");      // 43
        }
        //Algoritmo Dijkstra apartir de un nodo a todos los demas   
        public void DijkstraN(NodeP actual)
        {
            DistanciayNodoAnterior = new Dictionary<NodeP, Tuple<string, NodeP>>();
            vectorRelacionCambios = new List<List<string>>();
            HashSet<NodeP> nodosVisitados = new HashSet<NodeP>();
            //llenamos el diccionario de el nodo actual con distancia inf hacia un nodo null para todoos los nodos del grafo
            foreach (var nodo in grafo)
            {
                DistanciayNodoAnterior[nodo] = new Tuple<string, NodeP>(inf, null);
            }
            //
            DistanciayNodoAnterior[actual] = new Tuple<string, NodeP>("0", null);

            List<string> vectorRelacionOriginal = new List<string>();


            foreach (var nodo in grafo)
            {
                vectorRelacionOriginal.Add(DistanciayNodoAnterior[nodo].Item1);
            }

            vectorRelacionCambios.Add(vectorRelacionOriginal);

            while (true)
            {
                NodeP nodoMinimo = null;
                string distanciaMinima = inf;

                // Encuentra el nodo con la distancia mínima no visitado
                foreach (var nodo in grafo)
                {
                    if (!nodosVisitados.Contains(nodo) && string.Compare(DistanciayNodoAnterior[nodo].Item1, distanciaMinima) < 0)
                    {
                        nodoMinimo = nodo;
                        distanciaMinima = DistanciayNodoAnterior[nodo].Item1;
                    }
                }

                if (nodoMinimo == null)
                {
                    // Todos los nodos han sido visitados
                    break;
                }

                nodosVisitados.Add(nodoMinimo);

                foreach (var relacion in nodoMinimo.relations)
                {
                    NodeP vecino = relacion.Up;
                    if (!nodosVisitados.Contains(vecino))
                    {
                        Edge arista = grafo.GetEdge(nodoMinimo, vecino);
                        if (arista != null)
                        {
                            int distanciaActual = int.Parse(DistanciayNodoAnterior[nodoMinimo].Item1);
                            int distanciaTentativa = distanciaActual + arista.Weight;

                            if (DistanciayNodoAnterior[vecino].Item1 == inf)
                            {
                                DistanciayNodoAnterior[vecino] = new Tuple<string, NodeP>(distanciaTentativa.ToString(), nodoMinimo);
                            }
                            else
                            {
                                int distanciaExistente = int.Parse(DistanciayNodoAnterior[vecino].Item1);

                                if (distanciaTentativa < distanciaExistente)
                                {
                                    DistanciayNodoAnterior[vecino] = new Tuple<string, NodeP>(distanciaTentativa.ToString(), nodoMinimo);
                                }
                            }


                        }
                    }
                }

                // Registra los cambios en el vector de relación de costos
                List<string> vectorRelacionCambio = new List<string>();
                foreach (var nodo in grafo)
                {
                    vectorRelacionCambio.Add(DistanciayNodoAnterior[nodo].Item1);
                }
                vectorRelacionCambios.Add(vectorRelacionCambio);
            }
            string nombreBoton = "Ciudad" + raizActual.Name;
            raizActual = destino;
            imprime1(destino);
            Button boton = Controls.Find(nombreBoton, true).FirstOrDefault() as Button;
            if (boton != null)
            {
                boton.Image = Properties.Resources.game;
            }
        }
        public void imprime1(NodeP nodoDestino)
        {
            Recorrido.Items.Clear(); // Borra el contenido anterior del ListBox
            List<string> camino = new List<string>();
            NodeP nodoActual = nodoDestino;
            List<string> nombres = new List<string>();

            while (nodoActual != null)
            {
                camino.Add(ciudades[int.Parse(nodoActual.Name)]);
                nombres.Add(nodoActual.Name);
                nodoActual = DistanciayNodoAnterior[nodoActual].Item2;
            }
            camino.Reverse();
            nombres.Reverse();
            for (int i = 1; i < nombres.Count; i++)
            {
                MessageBox.Show("Ve a : " + ciudades[int.Parse(nombres[i])]);

                string nombreBoton = "Ciudad" + nombres[i];
                Button boton = Controls.Find(nombreBoton, true).FirstOrDefault() as Button;
                if (boton != null)
                {
                    boton.Image = Properties.Resources.c1;
                }
            }
            for (int i = 0; i < nombres.Count; i++)
            {
                string nombreBoton = "Ciudad" + nombres[i];
                Button boton = Controls.Find(nombreBoton, true).FirstOrDefault() as Button;
                if (boton != null)
                {
                    boton.Image = Properties.Resources.game;
                }
            }

            for (int i = 0; i < camino.Count; i++)
            {
                if (i > 0)
                {
                    Recorrido.Items.Add("diríjase a");
                }

                Recorrido.Items.Add(camino[i]);
            }

        }



        private void Ciudad0_Click(object sender, EventArgs e)
        {
            int i = 0;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad0.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad1_Click(object sender, EventArgs e)
        {
            int i = 1;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad1.Image = Properties.Resources.c1;
            }

        }
        private void Ciudad2_Click(object sender, EventArgs e)
        {
            int i = 2;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad2.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad3_Click(object sender, EventArgs e)
        {
            int i = 3;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad3.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad4_Click(object sender, EventArgs e)
        {
            int i = 4;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);

                Ciudad4.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad5_Click(object sender, EventArgs e)
        {
            int i = 5;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad5.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad6_Click(object sender, EventArgs e)
        {
            int i = 6;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad6.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad7_Click(object sender, EventArgs e)
        {
            int i = 7;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad7.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad8_Click(object sender, EventArgs e)
        {
            int i = 8;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad8.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad9_Click(object sender, EventArgs e)
        {
            int i = 9;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad9.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad10_Click(object sender, EventArgs e)
        {
            int i = 10;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad10.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad11_Click(object sender, EventArgs e)
        {
            int i = 11;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad11.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad12_Click(object sender, EventArgs e)
        {
            int i = 12;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad12.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad13_Click(object sender, EventArgs e)
        {
            int i = 13;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad13.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad14_Click(object sender, EventArgs e)
        {
            int i = 14;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad14.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad15_Click(object sender, EventArgs e)
        {
            int i = 15;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad15.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad16_Click(object sender, EventArgs e)
        {
            int i = 16;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad16.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad17_Click(object sender, EventArgs e)
        {
            int i = 17;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad17.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad18_Click(object sender, EventArgs e)
        {
            int i = 18;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad18.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad19_Click(object sender, EventArgs e)
        {
            int i = 19;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad19.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad20_Click(object sender, EventArgs e)
        {
            int i = 20;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad20.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad21_Click(object sender, EventArgs e)
        {
            int i = 21;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad21.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad22_Click(object sender, EventArgs e)
        {
            int i = 22;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");

            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad22.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad23_Click(object sender, EventArgs e)
        {
            int i = 23;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad23.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad24_Click(object sender, EventArgs e)
        {
            int i = 24;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad24.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad25_Click(object sender, EventArgs e)
        {
            int i = 25;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad25.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad26_Click(object sender, EventArgs e)
        {
            int i = 26;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad26.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad27_Click(object sender, EventArgs e)
        {
            int i = 27;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);

                Ciudad27.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad28_Click(object sender, EventArgs e)
        {
            int i = 28;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);

                Ciudad28.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad29_Click(object sender, EventArgs e)
        {
            int i = 29;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad29.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad30_Click(object sender, EventArgs e)
        {
            int i = 30;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad30.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad31_Click(object sender, EventArgs e)
        {
            int i = 31;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);

                Ciudad31.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad32_Click(object sender, EventArgs e)
        {
            int i = 32;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad32.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad33_Click(object sender, EventArgs e)
        {
            int i = 33;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad33.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad34_Click(object sender, EventArgs e)
        {
            int i = 34;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad34.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad35_Click(object sender, EventArgs e)
        {
            int i = 35;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad35.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad36_Click(object sender, EventArgs e)
        {
            int i = 36;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad36.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad37_Click(object sender, EventArgs e)
        {
            int i = 37;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad37.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad38_Click(object sender, EventArgs e)
        {
            int i = 38;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad38.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad39_Click(object sender, EventArgs e)
        {
            int i = 39;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad39.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad40_Click(object sender, EventArgs e)
        {
            int i = 40;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad40.Image = Properties.Resources.c1;
            }
        }

        private void Ciudad41_Click(object sender, EventArgs e)
        {
            int i = 41;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad41.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad42_Click(object sender, EventArgs e)
        {
            int i = 42;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad42.Image = Properties.Resources.c1;
            }

        }

        private void Ciudad43_Click(object sender, EventArgs e)
        {
            int i = 43;
            MessageBox.Show("Eijio la ciudad:" + ciudades[i]);
            if (Origen.Text == ciudades[i])
            {
                MessageBox.Show("Ya estas en esta ciudad");
            }
            else
            {
                Origen.Text = ciudades[i];
                destino = grafo.Find(n => n.Name == i.ToString());
                DijkstraN(raizActual);
                Ciudad43.Image = Properties.Resources.c1;
            }
        }

        private void Proyecto_Load(object sender, EventArgs e)
        {

        }

        private void Global_MouseLeave(object sender, EventArgs e)
        {
            if (sender is Control control)
            {
                string nombre = "l" + control.Name;
                Label h = Controls.Find(nombre, true).FirstOrDefault() as Label;

                if (h != null)
                {
                    h.Visible = false;
                }
            }
        }
        private void Global_MouseMove(object sender, MouseEventArgs e)
        {
            if (sender is Control control)
            {
                string nombre = "l" + control.Name;
                Label h = Controls.Find(nombre, true).FirstOrDefault() as Label;

                if (h != null)
                {
                    h.Visible = true;
                }
            }
        }
        public void asignarnombreLabel()
        {
            for (int i = 0; i <= 43; i++)
            {

                string nombre = "lCiudad" + i;
                Label h = Controls.Find(nombre, true).FirstOrDefault() as Label;

                if (h != null)
                {
                    h.Text = ciudades[i];
                }
            }
        }

    }
}

