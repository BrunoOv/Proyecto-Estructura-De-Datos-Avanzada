﻿namespace EditordeGrafos
{
    partial class Proyecto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Proyecto));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Ejemplo1 = new System.Windows.Forms.PictureBox();
            this.Ejemplo2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Origen = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Ciudad0 = new System.Windows.Forms.Button();
            this.Ciudad1 = new System.Windows.Forms.Button();
            this.Ciudad6 = new System.Windows.Forms.Button();
            this.Ciudad2 = new System.Windows.Forms.Button();
            this.Ciudad3 = new System.Windows.Forms.Button();
            this.Ciudad5 = new System.Windows.Forms.Button();
            this.Ciudad4 = new System.Windows.Forms.Button();
            this.Ciudad11 = new System.Windows.Forms.Button();
            this.Ciudad13 = new System.Windows.Forms.Button();
            this.Ciudad9 = new System.Windows.Forms.Button();
            this.Ciudad7 = new System.Windows.Forms.Button();
            this.Ciudad8 = new System.Windows.Forms.Button();
            this.Ciudad10 = new System.Windows.Forms.Button();
            this.Ciudad12 = new System.Windows.Forms.Button();
            this.Ciudad14 = new System.Windows.Forms.Button();
            this.Ciudad15 = new System.Windows.Forms.Button();
            this.Ciudad16 = new System.Windows.Forms.Button();
            this.Ciudad17 = new System.Windows.Forms.Button();
            this.Ciudad21 = new System.Windows.Forms.Button();
            this.Ciudad37 = new System.Windows.Forms.Button();
            this.Ciudad36 = new System.Windows.Forms.Button();
            this.Ciudad35 = new System.Windows.Forms.Button();
            this.Ciudad42 = new System.Windows.Forms.Button();
            this.Ciudad43 = new System.Windows.Forms.Button();
            this.Ciudad41 = new System.Windows.Forms.Button();
            this.Ciudad40 = new System.Windows.Forms.Button();
            this.Ciudad39 = new System.Windows.Forms.Button();
            this.Ciudad38 = new System.Windows.Forms.Button();
            this.Ciudad34 = new System.Windows.Forms.Button();
            this.Ciudad33 = new System.Windows.Forms.Button();
            this.Ciudad29 = new System.Windows.Forms.Button();
            this.Ciudad30 = new System.Windows.Forms.Button();
            this.Ciudad31 = new System.Windows.Forms.Button();
            this.Ciudad32 = new System.Windows.Forms.Button();
            this.Ciudad19 = new System.Windows.Forms.Button();
            this.Ciudad18 = new System.Windows.Forms.Button();
            this.Ciudad20 = new System.Windows.Forms.Button();
            this.Ciudad24 = new System.Windows.Forms.Button();
            this.Ciudad23 = new System.Windows.Forms.Button();
            this.Ciudad25 = new System.Windows.Forms.Button();
            this.Ciudad27 = new System.Windows.Forms.Button();
            this.Ciudad28 = new System.Windows.Forms.Button();
            this.Ciudad26 = new System.Windows.Forms.Button();
            this.Ciudad22 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Recorrido = new System.Windows.Forms.ListBox();
            this.lCiudad0 = new System.Windows.Forms.Label();
            this.lCiudad35 = new System.Windows.Forms.Label();
            this.lCiudad36 = new System.Windows.Forms.Label();
            this.lCiudad42 = new System.Windows.Forms.Label();
            this.lCiudad43 = new System.Windows.Forms.Label();
            this.lCiudad41 = new System.Windows.Forms.Label();
            this.lCiudad40 = new System.Windows.Forms.Label();
            this.lCiudad39 = new System.Windows.Forms.Label();
            this.lCiudad2 = new System.Windows.Forms.Label();
            this.lCiudad38 = new System.Windows.Forms.Label();
            this.lCiudad37 = new System.Windows.Forms.Label();
            this.lCiudad3 = new System.Windows.Forms.Label();
            this.lCiudad5 = new System.Windows.Forms.Label();
            this.lCiudad6 = new System.Windows.Forms.Label();
            this.lCiudad8 = new System.Windows.Forms.Label();
            this.lCiudad32 = new System.Windows.Forms.Label();
            this.lCiudad31 = new System.Windows.Forms.Label();
            this.lCiudad30 = new System.Windows.Forms.Label();
            this.lCiudad29 = new System.Windows.Forms.Label();
            this.lCiudad33 = new System.Windows.Forms.Label();
            this.lCiudad34 = new System.Windows.Forms.Label();
            this.lCiudad18 = new System.Windows.Forms.Label();
            this.lCiudad19 = new System.Windows.Forms.Label();
            this.lCiudad13 = new System.Windows.Forms.Label();
            this.lCiudad4 = new System.Windows.Forms.Label();
            this.lCiudad11 = new System.Windows.Forms.Label();
            this.lCiudad9 = new System.Windows.Forms.Label();
            this.lCiudad7 = new System.Windows.Forms.Label();
            this.lCiudad12 = new System.Windows.Forms.Label();
            this.lCiudad24 = new System.Windows.Forms.Label();
            this.lCiudad1 = new System.Windows.Forms.Label();
            this.lCiudad23 = new System.Windows.Forms.Label();
            this.lCiudad28 = new System.Windows.Forms.Label();
            this.lCiudad27 = new System.Windows.Forms.Label();
            this.lCiudad26 = new System.Windows.Forms.Label();
            this.lCiudad25 = new System.Windows.Forms.Label();
            this.lCiudad20 = new System.Windows.Forms.Label();
            this.lCiudad22 = new System.Windows.Forms.Label();
            this.lCiudad21 = new System.Windows.Forms.Label();
            this.lCiudad10 = new System.Windows.Forms.Label();
            this.lCiudad14 = new System.Windows.Forms.Label();
            this.lCiudad17 = new System.Windows.Forms.Label();
            this.lCiudad15 = new System.Windows.Forms.Label();
            this.lCiudad16 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ejemplo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ejemplo2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::EditordeGrafos.Properties.Resources.kalos;
            this.pictureBox1.Location = new System.Drawing.Point(12, 46);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(601, 599);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Ejemplo1
            // 
            this.Ejemplo1.Image = global::EditordeGrafos.Properties.Resources.c1;
            this.Ejemplo1.Location = new System.Drawing.Point(620, 193);
            this.Ejemplo1.Name = "Ejemplo1";
            this.Ejemplo1.Size = new System.Drawing.Size(40, 23);
            this.Ejemplo1.TabIndex = 1;
            this.Ejemplo1.TabStop = false;
            // 
            // Ejemplo2
            // 
            this.Ejemplo2.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ejemplo2.Location = new System.Drawing.Point(619, 243);
            this.Ejemplo2.Name = "Ejemplo2";
            this.Ejemplo2.Size = new System.Drawing.Size(41, 44);
            this.Ejemplo2.TabIndex = 2;
            this.Ejemplo2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(666, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Te encuentras aqui";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(666, 255);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ciudades";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "La Ciudad Actual Es: ";
            // 
            // Origen
            // 
            this.Origen.AutoSize = true;
            this.Origen.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Origen.ForeColor = System.Drawing.Color.LightCoral;
            this.Origen.Location = new System.Drawing.Point(180, 9);
            this.Origen.Name = "Origen";
            this.Origen.Size = new System.Drawing.Size(178, 25);
            this.Origen.TabIndex = 7;
            this.Origen.Text = "Ciudad Luminalia";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(615, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 80);
            this.label4.TabIndex = 8;
            this.label4.Text = "Selecciona en el \r\nmapa la ciudad \r\nala que necesites\r\nir";
            // 
            // Ciudad0
            // 
            this.Ciudad0.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad0.AccessibleName = "";
            this.Ciudad0.BackColor = System.Drawing.Color.MistyRose;
            this.Ciudad0.FlatAppearance.BorderSize = 0;
            this.Ciudad0.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad0.ForeColor = System.Drawing.Color.Transparent;
            this.Ciudad0.Image = global::EditordeGrafos.Properties.Resources.c1;
            this.Ciudad0.Location = new System.Drawing.Point(302, 195);
            this.Ciudad0.Name = "Ciudad0";
            this.Ciudad0.Size = new System.Drawing.Size(34, 35);
            this.Ciudad0.TabIndex = 9;
            this.Ciudad0.UseVisualStyleBackColor = false;
            this.Ciudad0.Click += new System.EventHandler(this.Ciudad0_Click);
            this.Ciudad0.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad0.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad1
            // 
            this.Ciudad1.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad1.AccessibleName = "";
            this.Ciudad1.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad1.FlatAppearance.BorderSize = 0;
            this.Ciudad1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad1.ForeColor = System.Drawing.Color.White;
            this.Ciudad1.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad1.Location = new System.Drawing.Point(315, 415);
            this.Ciudad1.Name = "Ciudad1";
            this.Ciudad1.Size = new System.Drawing.Size(30, 37);
            this.Ciudad1.TabIndex = 10;
            this.Ciudad1.UseVisualStyleBackColor = false;
            this.Ciudad1.Click += new System.EventHandler(this.Ciudad1_Click);
            this.Ciudad1.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad6
            // 
            this.Ciudad6.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad6.AccessibleName = "";
            this.Ciudad6.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad6.FlatAppearance.BorderSize = 0;
            this.Ciudad6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad6.ForeColor = System.Drawing.Color.White;
            this.Ciudad6.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad6.Location = new System.Drawing.Point(517, 193);
            this.Ciudad6.Name = "Ciudad6";
            this.Ciudad6.Size = new System.Drawing.Size(30, 37);
            this.Ciudad6.TabIndex = 11;
            this.Ciudad6.UseVisualStyleBackColor = false;
            this.Ciudad6.Click += new System.EventHandler(this.Ciudad6_Click);
            this.Ciudad6.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad2
            // 
            this.Ciudad2.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad2.AccessibleName = "";
            this.Ciudad2.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad2.FlatAppearance.BorderSize = 0;
            this.Ciudad2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad2.ForeColor = System.Drawing.Color.White;
            this.Ciudad2.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad2.Location = new System.Drawing.Point(306, 77);
            this.Ciudad2.Name = "Ciudad2";
            this.Ciudad2.Size = new System.Drawing.Size(30, 49);
            this.Ciudad2.TabIndex = 12;
            this.Ciudad2.UseVisualStyleBackColor = false;
            this.Ciudad2.Click += new System.EventHandler(this.Ciudad2_Click);
            this.Ciudad2.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad3
            // 
            this.Ciudad3.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad3.AccessibleName = "";
            this.Ciudad3.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad3.FlatAppearance.BorderSize = 0;
            this.Ciudad3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad3.ForeColor = System.Drawing.Color.White;
            this.Ciudad3.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad3.Location = new System.Drawing.Point(359, 142);
            this.Ciudad3.Name = "Ciudad3";
            this.Ciudad3.Size = new System.Drawing.Size(30, 37);
            this.Ciudad3.TabIndex = 13;
            this.Ciudad3.UseVisualStyleBackColor = false;
            this.Ciudad3.Click += new System.EventHandler(this.Ciudad3_Click);
            this.Ciudad3.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad5
            // 
            this.Ciudad5.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad5.AccessibleName = "";
            this.Ciudad5.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad5.FlatAppearance.BorderSize = 0;
            this.Ciudad5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad5.ForeColor = System.Drawing.Color.White;
            this.Ciudad5.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad5.Location = new System.Drawing.Point(435, 132);
            this.Ciudad5.Name = "Ciudad5";
            this.Ciudad5.Size = new System.Drawing.Size(30, 37);
            this.Ciudad5.TabIndex = 14;
            this.Ciudad5.UseVisualStyleBackColor = false;
            this.Ciudad5.Click += new System.EventHandler(this.Ciudad5_Click);
            this.Ciudad5.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad4
            // 
            this.Ciudad4.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad4.AccessibleName = "";
            this.Ciudad4.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad4.FlatAppearance.BorderSize = 0;
            this.Ciudad4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad4.ForeColor = System.Drawing.Color.White;
            this.Ciudad4.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad4.Location = new System.Drawing.Point(406, 175);
            this.Ciudad4.Name = "Ciudad4";
            this.Ciudad4.Size = new System.Drawing.Size(30, 37);
            this.Ciudad4.TabIndex = 15;
            this.Ciudad4.UseVisualStyleBackColor = false;
            this.Ciudad4.Click += new System.EventHandler(this.Ciudad4_Click);
            this.Ciudad4.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad11
            // 
            this.Ciudad11.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad11.AccessibleName = "";
            this.Ciudad11.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad11.FlatAppearance.BorderSize = 0;
            this.Ciudad11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad11.ForeColor = System.Drawing.Color.White;
            this.Ciudad11.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad11.Location = new System.Drawing.Point(435, 218);
            this.Ciudad11.Name = "Ciudad11";
            this.Ciudad11.Size = new System.Drawing.Size(30, 37);
            this.Ciudad11.TabIndex = 16;
            this.Ciudad11.UseVisualStyleBackColor = false;
            this.Ciudad11.Click += new System.EventHandler(this.Ciudad11_Click);
            this.Ciudad11.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad11.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad13
            // 
            this.Ciudad13.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad13.AccessibleName = "";
            this.Ciudad13.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad13.FlatAppearance.BorderSize = 0;
            this.Ciudad13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad13.ForeColor = System.Drawing.Color.White;
            this.Ciudad13.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad13.Location = new System.Drawing.Point(482, 341);
            this.Ciudad13.Name = "Ciudad13";
            this.Ciudad13.Size = new System.Drawing.Size(30, 37);
            this.Ciudad13.TabIndex = 17;
            this.Ciudad13.UseVisualStyleBackColor = false;
            this.Ciudad13.Click += new System.EventHandler(this.Ciudad13_Click);
            this.Ciudad13.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad13.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad9
            // 
            this.Ciudad9.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad9.AccessibleName = "";
            this.Ciudad9.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad9.FlatAppearance.BorderSize = 0;
            this.Ciudad9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad9.ForeColor = System.Drawing.Color.White;
            this.Ciudad9.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad9.Location = new System.Drawing.Point(504, 270);
            this.Ciudad9.Name = "Ciudad9";
            this.Ciudad9.Size = new System.Drawing.Size(30, 37);
            this.Ciudad9.TabIndex = 18;
            this.Ciudad9.UseVisualStyleBackColor = false;
            this.Ciudad9.Click += new System.EventHandler(this.Ciudad9_Click);
            this.Ciudad9.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad7
            // 
            this.Ciudad7.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad7.AccessibleName = "";
            this.Ciudad7.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad7.FlatAppearance.BorderSize = 0;
            this.Ciudad7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad7.ForeColor = System.Drawing.Color.White;
            this.Ciudad7.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad7.Location = new System.Drawing.Point(553, 228);
            this.Ciudad7.Name = "Ciudad7";
            this.Ciudad7.Size = new System.Drawing.Size(30, 37);
            this.Ciudad7.TabIndex = 19;
            this.Ciudad7.UseVisualStyleBackColor = false;
            this.Ciudad7.Click += new System.EventHandler(this.Ciudad7_Click);
            this.Ciudad7.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad8
            // 
            this.Ciudad8.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad8.AccessibleName = "";
            this.Ciudad8.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad8.FlatAppearance.BorderSize = 0;
            this.Ciudad8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad8.ForeColor = System.Drawing.Color.White;
            this.Ciudad8.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad8.Location = new System.Drawing.Point(573, 185);
            this.Ciudad8.Name = "Ciudad8";
            this.Ciudad8.Size = new System.Drawing.Size(30, 37);
            this.Ciudad8.TabIndex = 20;
            this.Ciudad8.UseVisualStyleBackColor = false;
            this.Ciudad8.Click += new System.EventHandler(this.Ciudad8_Click);
            this.Ciudad8.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad10
            // 
            this.Ciudad10.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad10.AccessibleName = "";
            this.Ciudad10.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad10.FlatAppearance.BorderSize = 0;
            this.Ciudad10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad10.ForeColor = System.Drawing.Color.White;
            this.Ciudad10.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad10.Location = new System.Drawing.Point(419, 270);
            this.Ciudad10.Name = "Ciudad10";
            this.Ciudad10.Size = new System.Drawing.Size(46, 37);
            this.Ciudad10.TabIndex = 21;
            this.Ciudad10.UseVisualStyleBackColor = false;
            this.Ciudad10.Click += new System.EventHandler(this.Ciudad10_Click);
            this.Ciudad10.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad10.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad12
            // 
            this.Ciudad12.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad12.AccessibleName = "";
            this.Ciudad12.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad12.FlatAppearance.BorderSize = 0;
            this.Ciudad12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad12.ForeColor = System.Drawing.Color.White;
            this.Ciudad12.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad12.Location = new System.Drawing.Point(359, 270);
            this.Ciudad12.Name = "Ciudad12";
            this.Ciudad12.Size = new System.Drawing.Size(30, 37);
            this.Ciudad12.TabIndex = 22;
            this.Ciudad12.UseVisualStyleBackColor = false;
            this.Ciudad12.Click += new System.EventHandler(this.Ciudad12_Click);
            this.Ciudad12.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad12.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad14
            // 
            this.Ciudad14.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad14.AccessibleName = "";
            this.Ciudad14.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad14.FlatAppearance.BorderSize = 0;
            this.Ciudad14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad14.ForeColor = System.Drawing.Color.White;
            this.Ciudad14.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad14.Location = new System.Drawing.Point(392, 313);
            this.Ciudad14.Name = "Ciudad14";
            this.Ciudad14.Size = new System.Drawing.Size(30, 51);
            this.Ciudad14.TabIndex = 23;
            this.Ciudad14.UseVisualStyleBackColor = false;
            this.Ciudad14.Click += new System.EventHandler(this.Ciudad14_Click);
            this.Ciudad14.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad14.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad15
            // 
            this.Ciudad15.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad15.AccessibleName = "";
            this.Ciudad15.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad15.FlatAppearance.BorderSize = 0;
            this.Ciudad15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad15.ForeColor = System.Drawing.Color.White;
            this.Ciudad15.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad15.Location = new System.Drawing.Point(383, 390);
            this.Ciudad15.Name = "Ciudad15";
            this.Ciudad15.Size = new System.Drawing.Size(30, 37);
            this.Ciudad15.TabIndex = 24;
            this.Ciudad15.UseVisualStyleBackColor = false;
            this.Ciudad15.Click += new System.EventHandler(this.Ciudad15_Click);
            this.Ciudad15.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad15.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad16
            // 
            this.Ciudad16.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad16.AccessibleName = "";
            this.Ciudad16.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad16.FlatAppearance.BorderSize = 0;
            this.Ciudad16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad16.ForeColor = System.Drawing.Color.White;
            this.Ciudad16.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad16.Location = new System.Drawing.Point(419, 380);
            this.Ciudad16.Name = "Ciudad16";
            this.Ciudad16.Size = new System.Drawing.Size(30, 37);
            this.Ciudad16.TabIndex = 25;
            this.Ciudad16.UseVisualStyleBackColor = false;
            this.Ciudad16.Click += new System.EventHandler(this.Ciudad16_Click);
            this.Ciudad16.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad16.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad17
            // 
            this.Ciudad17.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad17.AccessibleName = "";
            this.Ciudad17.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad17.FlatAppearance.BorderSize = 0;
            this.Ciudad17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad17.ForeColor = System.Drawing.Color.White;
            this.Ciudad17.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad17.Location = new System.Drawing.Point(455, 406);
            this.Ciudad17.Name = "Ciudad17";
            this.Ciudad17.Size = new System.Drawing.Size(30, 37);
            this.Ciudad17.TabIndex = 26;
            this.Ciudad17.UseVisualStyleBackColor = false;
            this.Ciudad17.Click += new System.EventHandler(this.Ciudad17_Click);
            this.Ciudad17.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad17.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad21
            // 
            this.Ciudad21.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad21.AccessibleName = "";
            this.Ciudad21.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad21.FlatAppearance.BorderSize = 0;
            this.Ciudad21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad21.ForeColor = System.Drawing.Color.White;
            this.Ciudad21.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad21.Location = new System.Drawing.Point(526, 565);
            this.Ciudad21.Name = "Ciudad21";
            this.Ciudad21.Size = new System.Drawing.Size(30, 37);
            this.Ciudad21.TabIndex = 27;
            this.Ciudad21.UseVisualStyleBackColor = false;
            this.Ciudad21.Click += new System.EventHandler(this.Ciudad21_Click);
            this.Ciudad21.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad21.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad37
            // 
            this.Ciudad37.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad37.AccessibleName = "";
            this.Ciudad37.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad37.FlatAppearance.BorderSize = 0;
            this.Ciudad37.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad37.ForeColor = System.Drawing.Color.White;
            this.Ciudad37.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad37.Location = new System.Drawing.Point(156, 113);
            this.Ciudad37.Name = "Ciudad37";
            this.Ciudad37.Size = new System.Drawing.Size(30, 37);
            this.Ciudad37.TabIndex = 28;
            this.Ciudad37.UseVisualStyleBackColor = false;
            this.Ciudad37.Click += new System.EventHandler(this.Ciudad37_Click);
            this.Ciudad37.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad37.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad36
            // 
            this.Ciudad36.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad36.AccessibleName = "";
            this.Ciudad36.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad36.FlatAppearance.BorderSize = 0;
            this.Ciudad36.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad36.ForeColor = System.Drawing.Color.White;
            this.Ciudad36.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad36.Location = new System.Drawing.Point(200, 156);
            this.Ciudad36.Name = "Ciudad36";
            this.Ciudad36.Size = new System.Drawing.Size(30, 37);
            this.Ciudad36.TabIndex = 29;
            this.Ciudad36.UseVisualStyleBackColor = false;
            this.Ciudad36.Click += new System.EventHandler(this.Ciudad36_Click);
            this.Ciudad36.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad36.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad35
            // 
            this.Ciudad35.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad35.AccessibleName = "";
            this.Ciudad35.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad35.FlatAppearance.BorderSize = 0;
            this.Ciudad35.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad35.ForeColor = System.Drawing.Color.White;
            this.Ciudad35.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad35.Location = new System.Drawing.Point(236, 190);
            this.Ciudad35.Name = "Ciudad35";
            this.Ciudad35.Size = new System.Drawing.Size(30, 45);
            this.Ciudad35.TabIndex = 30;
            this.Ciudad35.UseVisualStyleBackColor = false;
            this.Ciudad35.Click += new System.EventHandler(this.Ciudad35_Click);
            this.Ciudad35.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad35.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad42
            // 
            this.Ciudad42.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad42.AccessibleName = "";
            this.Ciudad42.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad42.FlatAppearance.BorderSize = 0;
            this.Ciudad42.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad42.ForeColor = System.Drawing.Color.White;
            this.Ciudad42.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad42.Location = new System.Drawing.Point(248, 270);
            this.Ciudad42.Name = "Ciudad42";
            this.Ciudad42.Size = new System.Drawing.Size(30, 37);
            this.Ciudad42.TabIndex = 31;
            this.Ciudad42.UseVisualStyleBackColor = false;
            this.Ciudad42.Click += new System.EventHandler(this.Ciudad42_Click);
            this.Ciudad42.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad42.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad43
            // 
            this.Ciudad43.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad43.AccessibleName = "";
            this.Ciudad43.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad43.FlatAppearance.BorderSize = 0;
            this.Ciudad43.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad43.ForeColor = System.Drawing.Color.White;
            this.Ciudad43.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad43.Location = new System.Drawing.Point(171, 218);
            this.Ciudad43.Name = "Ciudad43";
            this.Ciudad43.Size = new System.Drawing.Size(30, 37);
            this.Ciudad43.TabIndex = 32;
            this.Ciudad43.UseVisualStyleBackColor = false;
            this.Ciudad43.Click += new System.EventHandler(this.Ciudad43_Click);
            this.Ciudad43.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad43.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad41
            // 
            this.Ciudad41.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad41.AccessibleName = "";
            this.Ciudad41.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad41.FlatAppearance.BorderSize = 0;
            this.Ciudad41.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad41.ForeColor = System.Drawing.Color.White;
            this.Ciudad41.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad41.Location = new System.Drawing.Point(135, 270);
            this.Ciudad41.Name = "Ciudad41";
            this.Ciudad41.Size = new System.Drawing.Size(30, 37);
            this.Ciudad41.TabIndex = 33;
            this.Ciudad41.UseVisualStyleBackColor = false;
            this.Ciudad41.Click += new System.EventHandler(this.Ciudad41_Click);
            this.Ciudad41.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad41.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad40
            // 
            this.Ciudad40.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad40.AccessibleName = "";
            this.Ciudad40.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad40.FlatAppearance.BorderSize = 0;
            this.Ciudad40.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad40.ForeColor = System.Drawing.Color.White;
            this.Ciudad40.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad40.Location = new System.Drawing.Point(99, 270);
            this.Ciudad40.Name = "Ciudad40";
            this.Ciudad40.Size = new System.Drawing.Size(30, 37);
            this.Ciudad40.TabIndex = 34;
            this.Ciudad40.UseVisualStyleBackColor = false;
            this.Ciudad40.Click += new System.EventHandler(this.Ciudad40_Click);
            this.Ciudad40.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad40.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad39
            // 
            this.Ciudad39.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad39.AccessibleName = "";
            this.Ciudad39.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad39.FlatAppearance.BorderSize = 0;
            this.Ciudad39.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad39.ForeColor = System.Drawing.Color.White;
            this.Ciudad39.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad39.Location = new System.Drawing.Point(51, 243);
            this.Ciudad39.Name = "Ciudad39";
            this.Ciudad39.Size = new System.Drawing.Size(30, 37);
            this.Ciudad39.TabIndex = 35;
            this.Ciudad39.UseVisualStyleBackColor = false;
            this.Ciudad39.Click += new System.EventHandler(this.Ciudad39_Click);
            this.Ciudad39.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad39.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad38
            // 
            this.Ciudad38.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad38.AccessibleName = "";
            this.Ciudad38.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad38.FlatAppearance.BorderSize = 0;
            this.Ciudad38.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad38.ForeColor = System.Drawing.Color.White;
            this.Ciudad38.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad38.Location = new System.Drawing.Point(77, 193);
            this.Ciudad38.Name = "Ciudad38";
            this.Ciudad38.Size = new System.Drawing.Size(37, 44);
            this.Ciudad38.TabIndex = 36;
            this.Ciudad38.UseVisualStyleBackColor = false;
            this.Ciudad38.Click += new System.EventHandler(this.Ciudad38_Click);
            this.Ciudad38.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad38.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad34
            // 
            this.Ciudad34.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad34.AccessibleName = "";
            this.Ciudad34.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad34.FlatAppearance.BorderSize = 0;
            this.Ciudad34.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad34.ForeColor = System.Drawing.Color.White;
            this.Ciudad34.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad34.Location = new System.Drawing.Point(218, 341);
            this.Ciudad34.Name = "Ciudad34";
            this.Ciudad34.Size = new System.Drawing.Size(30, 37);
            this.Ciudad34.TabIndex = 37;
            this.Ciudad34.UseVisualStyleBackColor = false;
            this.Ciudad34.Click += new System.EventHandler(this.Ciudad34_Click);
            this.Ciudad34.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad34.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad33
            // 
            this.Ciudad33.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad33.AccessibleName = "";
            this.Ciudad33.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad33.FlatAppearance.BorderSize = 0;
            this.Ciudad33.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad33.ForeColor = System.Drawing.Color.White;
            this.Ciudad33.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad33.Location = new System.Drawing.Point(156, 341);
            this.Ciudad33.Name = "Ciudad33";
            this.Ciudad33.Size = new System.Drawing.Size(30, 37);
            this.Ciudad33.TabIndex = 38;
            this.Ciudad33.UseVisualStyleBackColor = false;
            this.Ciudad33.Click += new System.EventHandler(this.Ciudad33_Click);
            this.Ciudad33.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad33.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad29
            // 
            this.Ciudad29.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad29.AccessibleName = "";
            this.Ciudad29.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad29.FlatAppearance.BorderSize = 0;
            this.Ciudad29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad29.ForeColor = System.Drawing.Color.White;
            this.Ciudad29.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad29.Location = new System.Drawing.Point(156, 406);
            this.Ciudad29.Name = "Ciudad29";
            this.Ciudad29.Size = new System.Drawing.Size(30, 56);
            this.Ciudad29.TabIndex = 39;
            this.Ciudad29.UseVisualStyleBackColor = false;
            this.Ciudad29.Click += new System.EventHandler(this.Ciudad29_Click);
            this.Ciudad29.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad29.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad30
            // 
            this.Ciudad30.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad30.AccessibleName = "";
            this.Ciudad30.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad30.FlatAppearance.BorderSize = 0;
            this.Ciudad30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad30.ForeColor = System.Drawing.Color.White;
            this.Ciudad30.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad30.Location = new System.Drawing.Point(84, 425);
            this.Ciudad30.Name = "Ciudad30";
            this.Ciudad30.Size = new System.Drawing.Size(30, 37);
            this.Ciudad30.TabIndex = 40;
            this.Ciudad30.UseVisualStyleBackColor = false;
            this.Ciudad30.Click += new System.EventHandler(this.Ciudad30_Click);
            this.Ciudad30.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad30.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad31
            // 
            this.Ciudad31.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad31.AccessibleName = "";
            this.Ciudad31.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad31.FlatAppearance.BorderSize = 0;
            this.Ciudad31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad31.ForeColor = System.Drawing.Color.White;
            this.Ciudad31.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad31.Location = new System.Drawing.Point(63, 482);
            this.Ciudad31.Name = "Ciudad31";
            this.Ciudad31.Size = new System.Drawing.Size(30, 37);
            this.Ciudad31.TabIndex = 41;
            this.Ciudad31.UseVisualStyleBackColor = false;
            this.Ciudad31.Click += new System.EventHandler(this.Ciudad31_Click);
            this.Ciudad31.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad31.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad32
            // 
            this.Ciudad32.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad32.AccessibleName = "";
            this.Ciudad32.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad32.FlatAppearance.BorderSize = 0;
            this.Ciudad32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad32.ForeColor = System.Drawing.Color.White;
            this.Ciudad32.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad32.Location = new System.Drawing.Point(33, 540);
            this.Ciudad32.Name = "Ciudad32";
            this.Ciudad32.Size = new System.Drawing.Size(30, 37);
            this.Ciudad32.TabIndex = 42;
            this.Ciudad32.UseVisualStyleBackColor = false;
            this.Ciudad32.Click += new System.EventHandler(this.Ciudad32_Click);
            this.Ciudad32.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad32.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad19
            // 
            this.Ciudad19.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad19.AccessibleName = "";
            this.Ciudad19.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad19.FlatAppearance.BorderSize = 0;
            this.Ciudad19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad19.ForeColor = System.Drawing.Color.White;
            this.Ciudad19.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad19.Location = new System.Drawing.Point(482, 463);
            this.Ciudad19.Name = "Ciudad19";
            this.Ciudad19.Size = new System.Drawing.Size(30, 37);
            this.Ciudad19.TabIndex = 43;
            this.Ciudad19.UseVisualStyleBackColor = false;
            this.Ciudad19.Click += new System.EventHandler(this.Ciudad19_Click);
            this.Ciudad19.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad19.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad18
            // 
            this.Ciudad18.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad18.AccessibleName = "";
            this.Ciudad18.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad18.FlatAppearance.BorderSize = 0;
            this.Ciudad18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad18.ForeColor = System.Drawing.Color.White;
            this.Ciudad18.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad18.Location = new System.Drawing.Point(446, 449);
            this.Ciudad18.Name = "Ciudad18";
            this.Ciudad18.Size = new System.Drawing.Size(30, 37);
            this.Ciudad18.TabIndex = 44;
            this.Ciudad18.UseVisualStyleBackColor = false;
            this.Ciudad18.Click += new System.EventHandler(this.Ciudad18_Click);
            this.Ciudad18.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad18.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad20
            // 
            this.Ciudad20.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad20.AccessibleName = "";
            this.Ciudad20.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad20.FlatAppearance.BorderSize = 0;
            this.Ciudad20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad20.ForeColor = System.Drawing.Color.White;
            this.Ciudad20.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad20.Location = new System.Drawing.Point(446, 565);
            this.Ciudad20.Name = "Ciudad20";
            this.Ciudad20.Size = new System.Drawing.Size(30, 37);
            this.Ciudad20.TabIndex = 45;
            this.Ciudad20.UseVisualStyleBackColor = false;
            this.Ciudad20.Click += new System.EventHandler(this.Ciudad20_Click);
            this.Ciudad20.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad20.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad24
            // 
            this.Ciudad24.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad24.AccessibleName = "";
            this.Ciudad24.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad24.FlatAppearance.BorderSize = 0;
            this.Ciudad24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad24.ForeColor = System.Drawing.Color.White;
            this.Ciudad24.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad24.Location = new System.Drawing.Point(359, 433);
            this.Ciudad24.Name = "Ciudad24";
            this.Ciudad24.Size = new System.Drawing.Size(30, 37);
            this.Ciudad24.TabIndex = 46;
            this.Ciudad24.UseVisualStyleBackColor = false;
            this.Ciudad24.Click += new System.EventHandler(this.Ciudad24_Click);
            this.Ciudad24.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad24.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad23
            // 
            this.Ciudad23.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad23.AccessibleName = "";
            this.Ciudad23.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad23.FlatAppearance.BorderSize = 0;
            this.Ciudad23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad23.ForeColor = System.Drawing.Color.White;
            this.Ciudad23.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad23.Location = new System.Drawing.Point(315, 463);
            this.Ciudad23.Name = "Ciudad23";
            this.Ciudad23.Size = new System.Drawing.Size(30, 37);
            this.Ciudad23.TabIndex = 47;
            this.Ciudad23.UseVisualStyleBackColor = false;
            this.Ciudad23.Click += new System.EventHandler(this.Ciudad23_Click);
            this.Ciudad23.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad23.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad25
            // 
            this.Ciudad25.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad25.AccessibleName = "";
            this.Ciudad25.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad25.FlatAppearance.BorderSize = 0;
            this.Ciudad25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad25.ForeColor = System.Drawing.Color.White;
            this.Ciudad25.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad25.Location = new System.Drawing.Point(315, 522);
            this.Ciudad25.Name = "Ciudad25";
            this.Ciudad25.Size = new System.Drawing.Size(43, 43);
            this.Ciudad25.TabIndex = 48;
            this.Ciudad25.UseVisualStyleBackColor = false;
            this.Ciudad25.Click += new System.EventHandler(this.Ciudad25_Click);
            this.Ciudad25.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad25.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad27
            // 
            this.Ciudad27.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad27.AccessibleName = "";
            this.Ciudad27.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad27.FlatAppearance.BorderSize = 0;
            this.Ciudad27.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad27.ForeColor = System.Drawing.Color.White;
            this.Ciudad27.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad27.Location = new System.Drawing.Point(209, 482);
            this.Ciudad27.Name = "Ciudad27";
            this.Ciudad27.Size = new System.Drawing.Size(48, 48);
            this.Ciudad27.TabIndex = 49;
            this.Ciudad27.UseVisualStyleBackColor = false;
            this.Ciudad27.Click += new System.EventHandler(this.Ciudad27_Click);
            this.Ciudad27.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad27.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad28
            // 
            this.Ciudad28.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad28.AccessibleName = "";
            this.Ciudad28.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad28.FlatAppearance.BorderSize = 0;
            this.Ciudad28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad28.ForeColor = System.Drawing.Color.White;
            this.Ciudad28.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad28.Location = new System.Drawing.Point(156, 502);
            this.Ciudad28.Name = "Ciudad28";
            this.Ciudad28.Size = new System.Drawing.Size(30, 37);
            this.Ciudad28.TabIndex = 50;
            this.Ciudad28.UseVisualStyleBackColor = false;
            this.Ciudad28.Click += new System.EventHandler(this.Ciudad28_Click);
            this.Ciudad28.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad28.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad26
            // 
            this.Ciudad26.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad26.AccessibleName = "";
            this.Ciudad26.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad26.FlatAppearance.BorderSize = 0;
            this.Ciudad26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad26.ForeColor = System.Drawing.Color.White;
            this.Ciudad26.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad26.Location = new System.Drawing.Point(171, 565);
            this.Ciudad26.Name = "Ciudad26";
            this.Ciudad26.Size = new System.Drawing.Size(30, 37);
            this.Ciudad26.TabIndex = 51;
            this.Ciudad26.UseVisualStyleBackColor = false;
            this.Ciudad26.Click += new System.EventHandler(this.Ciudad26_Click);
            this.Ciudad26.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad26.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // Ciudad22
            // 
            this.Ciudad22.AccessibleDescription = "Ciudad Luminalia";
            this.Ciudad22.AccessibleName = "";
            this.Ciudad22.BackColor = System.Drawing.Color.Transparent;
            this.Ciudad22.FlatAppearance.BorderSize = 0;
            this.Ciudad22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Ciudad22.ForeColor = System.Drawing.Color.White;
            this.Ciudad22.Image = global::EditordeGrafos.Properties.Resources.game;
            this.Ciudad22.Location = new System.Drawing.Point(446, 608);
            this.Ciudad22.Name = "Ciudad22";
            this.Ciudad22.Size = new System.Drawing.Size(30, 37);
            this.Ciudad22.TabIndex = 52;
            this.Ciudad22.UseVisualStyleBackColor = false;
            this.Ciudad22.Click += new System.EventHandler(this.Ciudad22_Click);
            this.Ciudad22.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.Ciudad22.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(616, 298);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 80);
            this.label6.TabIndex = 56;
            this.label6.Text = "Cuando elijas\r\nuna ciudad\r\ncomenzara el \r\nrecorrido\r\n";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(620, 403);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 57;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(616, 396);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(146, 20);
            this.label8.TabIndex = 58;
            this.label8.Text = "Recorrido Anterior: ";
            // 
            // Recorrido
            // 
            this.Recorrido.FormattingEnabled = true;
            this.Recorrido.Location = new System.Drawing.Point(619, 415);
            this.Recorrido.Name = "Recorrido";
            this.Recorrido.Size = new System.Drawing.Size(179, 251);
            this.Recorrido.TabIndex = 59;
            // 
            // lCiudad0
            // 
            this.lCiudad0.AutoSize = true;
            this.lCiudad0.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad0.Location = new System.Drawing.Point(294, 175);
            this.lCiudad0.Name = "lCiudad0";
            this.lCiudad0.Size = new System.Drawing.Size(51, 26);
            this.lCiudad0.TabIndex = 60;
            this.lCiudad0.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad0.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad0.Visible = false;
            // 
            // lCiudad35
            // 
            this.lCiudad35.AutoSize = true;
            this.lCiudad35.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad35.Location = new System.Drawing.Point(227, 175);
            this.lCiudad35.Name = "lCiudad35";
            this.lCiudad35.Size = new System.Drawing.Size(51, 26);
            this.lCiudad35.TabIndex = 61;
            this.lCiudad35.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad35.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad35.Visible = false;
            // 
            // lCiudad36
            // 
            this.lCiudad36.AutoSize = true;
            this.lCiudad36.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad36.Location = new System.Drawing.Point(192, 132);
            this.lCiudad36.Name = "lCiudad36";
            this.lCiudad36.Size = new System.Drawing.Size(51, 26);
            this.lCiudad36.TabIndex = 62;
            this.lCiudad36.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad36.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad36.Visible = false;
            // 
            // lCiudad42
            // 
            this.lCiudad42.AutoSize = true;
            this.lCiudad42.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad42.Location = new System.Drawing.Point(268, 270);
            this.lCiudad42.Name = "lCiudad42";
            this.lCiudad42.Size = new System.Drawing.Size(51, 26);
            this.lCiudad42.TabIndex = 63;
            this.lCiudad42.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad42.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad42.Visible = false;
            // 
            // lCiudad43
            // 
            this.lCiudad43.AutoSize = true;
            this.lCiudad43.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad43.Location = new System.Drawing.Point(150, 197);
            this.lCiudad43.Name = "lCiudad43";
            this.lCiudad43.Size = new System.Drawing.Size(51, 26);
            this.lCiudad43.TabIndex = 64;
            this.lCiudad43.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad43.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad43.Visible = false;
            // 
            // lCiudad41
            // 
            this.lCiudad41.AutoSize = true;
            this.lCiudad41.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad41.Location = new System.Drawing.Point(150, 298);
            this.lCiudad41.Name = "lCiudad41";
            this.lCiudad41.Size = new System.Drawing.Size(51, 26);
            this.lCiudad41.TabIndex = 65;
            this.lCiudad41.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad41.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad41.Visible = false;
            // 
            // lCiudad40
            // 
            this.lCiudad40.AutoSize = true;
            this.lCiudad40.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad40.Location = new System.Drawing.Point(74, 303);
            this.lCiudad40.Name = "lCiudad40";
            this.lCiudad40.Size = new System.Drawing.Size(51, 26);
            this.lCiudad40.TabIndex = 66;
            this.lCiudad40.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad40.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad40.Visible = false;
            // 
            // lCiudad39
            // 
            this.lCiudad39.AutoSize = true;
            this.lCiudad39.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad39.Location = new System.Drawing.Point(9, 254);
            this.lCiudad39.Name = "lCiudad39";
            this.lCiudad39.Size = new System.Drawing.Size(51, 26);
            this.lCiudad39.TabIndex = 67;
            this.lCiudad39.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad39.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad39.Visible = false;
            // 
            // lCiudad2
            // 
            this.lCiudad2.AutoSize = true;
            this.lCiudad2.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad2.Location = new System.Drawing.Point(294, 58);
            this.lCiudad2.Name = "lCiudad2";
            this.lCiudad2.Size = new System.Drawing.Size(51, 26);
            this.lCiudad2.TabIndex = 68;
            this.lCiudad2.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad2.Visible = false;
            // 
            // lCiudad38
            // 
            this.lCiudad38.AutoSize = true;
            this.lCiudad38.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad38.Location = new System.Drawing.Point(63, 168);
            this.lCiudad38.Name = "lCiudad38";
            this.lCiudad38.Size = new System.Drawing.Size(51, 26);
            this.lCiudad38.TabIndex = 69;
            this.lCiudad38.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad38.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad38.Visible = false;
            // 
            // lCiudad37
            // 
            this.lCiudad37.AutoSize = true;
            this.lCiudad37.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad37.Location = new System.Drawing.Point(150, 95);
            this.lCiudad37.Name = "lCiudad37";
            this.lCiudad37.Size = new System.Drawing.Size(51, 26);
            this.lCiudad37.TabIndex = 70;
            this.lCiudad37.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad37.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad37.Visible = false;
            // 
            // lCiudad3
            // 
            this.lCiudad3.AutoSize = true;
            this.lCiudad3.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad3.Location = new System.Drawing.Point(356, 124);
            this.lCiudad3.Name = "lCiudad3";
            this.lCiudad3.Size = new System.Drawing.Size(51, 26);
            this.lCiudad3.TabIndex = 71;
            this.lCiudad3.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad3.Visible = false;
            // 
            // lCiudad5
            // 
            this.lCiudad5.AutoSize = true;
            this.lCiudad5.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad5.Location = new System.Drawing.Point(425, 113);
            this.lCiudad5.Name = "lCiudad5";
            this.lCiudad5.Size = new System.Drawing.Size(51, 26);
            this.lCiudad5.TabIndex = 72;
            this.lCiudad5.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad5.Visible = false;
            // 
            // lCiudad6
            // 
            this.lCiudad6.AutoSize = true;
            this.lCiudad6.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad6.Location = new System.Drawing.Point(505, 168);
            this.lCiudad6.Name = "lCiudad6";
            this.lCiudad6.Size = new System.Drawing.Size(51, 26);
            this.lCiudad6.TabIndex = 73;
            this.lCiudad6.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad6.Visible = false;
            // 
            // lCiudad8
            // 
            this.lCiudad8.AutoSize = true;
            this.lCiudad8.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad8.Location = new System.Drawing.Point(562, 167);
            this.lCiudad8.Name = "lCiudad8";
            this.lCiudad8.Size = new System.Drawing.Size(51, 26);
            this.lCiudad8.TabIndex = 74;
            this.lCiudad8.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad8.Visible = false;
            // 
            // lCiudad32
            // 
            this.lCiudad32.AutoSize = true;
            this.lCiudad32.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad32.Location = new System.Drawing.Point(60, 551);
            this.lCiudad32.Name = "lCiudad32";
            this.lCiudad32.Size = new System.Drawing.Size(51, 26);
            this.lCiudad32.TabIndex = 75;
            this.lCiudad32.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad32.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad32.Visible = false;
            // 
            // lCiudad31
            // 
            this.lCiudad31.AutoSize = true;
            this.lCiudad31.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad31.Location = new System.Drawing.Point(14, 493);
            this.lCiudad31.Name = "lCiudad31";
            this.lCiudad31.Size = new System.Drawing.Size(51, 26);
            this.lCiudad31.TabIndex = 76;
            this.lCiudad31.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad31.Visible = false;
            // 
            // lCiudad30
            // 
            this.lCiudad30.AutoSize = true;
            this.lCiudad30.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad30.Location = new System.Drawing.Point(74, 403);
            this.lCiudad30.Name = "lCiudad30";
            this.lCiudad30.Size = new System.Drawing.Size(51, 26);
            this.lCiudad30.TabIndex = 77;
            this.lCiudad30.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad30.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad30.Visible = false;
            // 
            // lCiudad29
            // 
            this.lCiudad29.AutoSize = true;
            this.lCiudad29.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad29.Location = new System.Drawing.Point(179, 415);
            this.lCiudad29.Name = "lCiudad29";
            this.lCiudad29.Size = new System.Drawing.Size(51, 26);
            this.lCiudad29.TabIndex = 78;
            this.lCiudad29.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad29.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad29.Visible = false;
            // 
            // lCiudad33
            // 
            this.lCiudad33.AutoSize = true;
            this.lCiudad33.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad33.Location = new System.Drawing.Point(114, 346);
            this.lCiudad33.Name = "lCiudad33";
            this.lCiudad33.Size = new System.Drawing.Size(51, 26);
            this.lCiudad33.TabIndex = 79;
            this.lCiudad33.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad33.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad33.Visible = false;
            // 
            // lCiudad34
            // 
            this.lCiudad34.AutoSize = true;
            this.lCiudad34.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad34.Location = new System.Drawing.Point(245, 353);
            this.lCiudad34.Name = "lCiudad34";
            this.lCiudad34.Size = new System.Drawing.Size(51, 26);
            this.lCiudad34.TabIndex = 80;
            this.lCiudad34.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad34.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad34.Visible = false;
            // 
            // lCiudad18
            // 
            this.lCiudad18.AutoSize = true;
            this.lCiudad18.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad18.Location = new System.Drawing.Point(398, 474);
            this.lCiudad18.Name = "lCiudad18";
            this.lCiudad18.Size = new System.Drawing.Size(51, 26);
            this.lCiudad18.TabIndex = 81;
            this.lCiudad18.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad18.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad18.Visible = false;
            // 
            // lCiudad19
            // 
            this.lCiudad19.AutoSize = true;
            this.lCiudad19.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad19.Location = new System.Drawing.Point(514, 463);
            this.lCiudad19.Name = "lCiudad19";
            this.lCiudad19.Size = new System.Drawing.Size(51, 26);
            this.lCiudad19.TabIndex = 82;
            this.lCiudad19.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad19.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad19.Visible = false;
            // 
            // lCiudad13
            // 
            this.lCiudad13.AutoSize = true;
            this.lCiudad13.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad13.Location = new System.Drawing.Point(505, 353);
            this.lCiudad13.Name = "lCiudad13";
            this.lCiudad13.Size = new System.Drawing.Size(51, 26);
            this.lCiudad13.TabIndex = 83;
            this.lCiudad13.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad13.Visible = false;
            // 
            // lCiudad4
            // 
            this.lCiudad4.AutoSize = true;
            this.lCiudad4.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad4.Location = new System.Drawing.Point(432, 185);
            this.lCiudad4.Name = "lCiudad4";
            this.lCiudad4.Size = new System.Drawing.Size(51, 26);
            this.lCiudad4.TabIndex = 84;
            this.lCiudad4.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad4.Visible = false;
            // 
            // lCiudad11
            // 
            this.lCiudad11.AutoSize = true;
            this.lCiudad11.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad11.Location = new System.Drawing.Point(389, 228);
            this.lCiudad11.Name = "lCiudad11";
            this.lCiudad11.Size = new System.Drawing.Size(51, 26);
            this.lCiudad11.TabIndex = 85;
            this.lCiudad11.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad11.Visible = false;
            // 
            // lCiudad9
            // 
            this.lCiudad9.AutoSize = true;
            this.lCiudad9.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad9.Location = new System.Drawing.Point(523, 298);
            this.lCiudad9.Name = "lCiudad9";
            this.lCiudad9.Size = new System.Drawing.Size(51, 26);
            this.lCiudad9.TabIndex = 86;
            this.lCiudad9.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad9.Visible = false;
            // 
            // lCiudad7
            // 
            this.lCiudad7.AutoSize = true;
            this.lCiudad7.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad7.Location = new System.Drawing.Point(562, 255);
            this.lCiudad7.Name = "lCiudad7";
            this.lCiudad7.Size = new System.Drawing.Size(51, 26);
            this.lCiudad7.TabIndex = 87;
            this.lCiudad7.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad7.Visible = false;
            // 
            // lCiudad12
            // 
            this.lCiudad12.AutoSize = true;
            this.lCiudad12.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad12.Location = new System.Drawing.Point(312, 270);
            this.lCiudad12.Name = "lCiudad12";
            this.lCiudad12.Size = new System.Drawing.Size(51, 26);
            this.lCiudad12.TabIndex = 88;
            this.lCiudad12.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad12.Visible = false;
            // 
            // lCiudad24
            // 
            this.lCiudad24.AutoSize = true;
            this.lCiudad24.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad24.Location = new System.Drawing.Point(385, 437);
            this.lCiudad24.Name = "lCiudad24";
            this.lCiudad24.Size = new System.Drawing.Size(51, 26);
            this.lCiudad24.TabIndex = 89;
            this.lCiudad24.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad24.Visible = false;
            // 
            // lCiudad1
            // 
            this.lCiudad1.AutoSize = true;
            this.lCiudad1.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad1.Location = new System.Drawing.Point(268, 415);
            this.lCiudad1.Name = "lCiudad1";
            this.lCiudad1.Size = new System.Drawing.Size(51, 26);
            this.lCiudad1.TabIndex = 90;
            this.lCiudad1.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad1.Visible = false;
            // 
            // lCiudad23
            // 
            this.lCiudad23.AutoSize = true;
            this.lCiudad23.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad23.Location = new System.Drawing.Point(268, 475);
            this.lCiudad23.Name = "lCiudad23";
            this.lCiudad23.Size = new System.Drawing.Size(51, 26);
            this.lCiudad23.TabIndex = 91;
            this.lCiudad23.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad23.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad23.Visible = false;
            // 
            // lCiudad28
            // 
            this.lCiudad28.AutoSize = true;
            this.lCiudad28.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad28.Location = new System.Drawing.Point(114, 504);
            this.lCiudad28.Name = "lCiudad28";
            this.lCiudad28.Size = new System.Drawing.Size(51, 26);
            this.lCiudad28.TabIndex = 92;
            this.lCiudad28.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad28.Visible = false;
            // 
            // lCiudad27
            // 
            this.lCiudad27.AutoSize = true;
            this.lCiudad27.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad27.Location = new System.Drawing.Point(206, 453);
            this.lCiudad27.Name = "lCiudad27";
            this.lCiudad27.Size = new System.Drawing.Size(51, 26);
            this.lCiudad27.TabIndex = 93;
            this.lCiudad27.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad27.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad27.Visible = false;
            // 
            // lCiudad26
            // 
            this.lCiudad26.AutoSize = true;
            this.lCiudad26.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad26.Location = new System.Drawing.Point(168, 605);
            this.lCiudad26.Name = "lCiudad26";
            this.lCiudad26.Size = new System.Drawing.Size(51, 26);
            this.lCiudad26.TabIndex = 94;
            this.lCiudad26.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad26.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad26.Visible = false;
            // 
            // lCiudad25
            // 
            this.lCiudad25.AutoSize = true;
            this.lCiudad25.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad25.Location = new System.Drawing.Point(294, 565);
            this.lCiudad25.Name = "lCiudad25";
            this.lCiudad25.Size = new System.Drawing.Size(51, 26);
            this.lCiudad25.TabIndex = 95;
            this.lCiudad25.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad25.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad25.Visible = false;
            // 
            // lCiudad20
            // 
            this.lCiudad20.AutoSize = true;
            this.lCiudad20.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad20.Location = new System.Drawing.Point(398, 565);
            this.lCiudad20.Name = "lCiudad20";
            this.lCiudad20.Size = new System.Drawing.Size(51, 26);
            this.lCiudad20.TabIndex = 96;
            this.lCiudad20.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad20.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad20.Visible = false;
            // 
            // lCiudad22
            // 
            this.lCiudad22.AutoSize = true;
            this.lCiudad22.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad22.Location = new System.Drawing.Point(479, 608);
            this.lCiudad22.Name = "lCiudad22";
            this.lCiudad22.Size = new System.Drawing.Size(51, 26);
            this.lCiudad22.TabIndex = 97;
            this.lCiudad22.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad22.Visible = false;
            // 
            // lCiudad21
            // 
            this.lCiudad21.AutoSize = true;
            this.lCiudad21.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad21.Location = new System.Drawing.Point(552, 565);
            this.lCiudad21.Name = "lCiudad21";
            this.lCiudad21.Size = new System.Drawing.Size(51, 26);
            this.lCiudad21.TabIndex = 98;
            this.lCiudad21.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad21.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad21.Visible = false;
            // 
            // lCiudad10
            // 
            this.lCiudad10.AutoSize = true;
            this.lCiudad10.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad10.Location = new System.Drawing.Point(447, 298);
            this.lCiudad10.Name = "lCiudad10";
            this.lCiudad10.Size = new System.Drawing.Size(51, 26);
            this.lCiudad10.TabIndex = 99;
            this.lCiudad10.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad10.Visible = false;
            // 
            // lCiudad14
            // 
            this.lCiudad14.AutoSize = true;
            this.lCiudad14.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad14.Location = new System.Drawing.Point(338, 332);
            this.lCiudad14.Name = "lCiudad14";
            this.lCiudad14.Size = new System.Drawing.Size(51, 26);
            this.lCiudad14.TabIndex = 100;
            this.lCiudad14.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad14.Visible = false;
            // 
            // lCiudad17
            // 
            this.lCiudad17.AutoSize = true;
            this.lCiudad17.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad17.Location = new System.Drawing.Point(479, 406);
            this.lCiudad17.Name = "lCiudad17";
            this.lCiudad17.Size = new System.Drawing.Size(51, 26);
            this.lCiudad17.TabIndex = 101;
            this.lCiudad17.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad17.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad17.Visible = false;
            // 
            // lCiudad15
            // 
            this.lCiudad15.AutoSize = true;
            this.lCiudad15.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad15.Location = new System.Drawing.Point(338, 392);
            this.lCiudad15.Name = "lCiudad15";
            this.lCiudad15.Size = new System.Drawing.Size(51, 26);
            this.lCiudad15.TabIndex = 102;
            this.lCiudad15.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad15.Visible = false;
            // 
            // lCiudad16
            // 
            this.lCiudad16.AutoSize = true;
            this.lCiudad16.BackColor = System.Drawing.Color.SeaShell;
            this.lCiudad16.Location = new System.Drawing.Point(443, 377);
            this.lCiudad16.Name = "lCiudad16";
            this.lCiudad16.Size = new System.Drawing.Size(51, 26);
            this.lCiudad16.TabIndex = 103;
            this.lCiudad16.Text = "Ciudad \r\nLuminalia\r\n";
            this.lCiudad16.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lCiudad16.Visible = false;
            // 
            // Proyecto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(823, 670);
            this.Controls.Add(this.lCiudad16);
            this.Controls.Add(this.lCiudad15);
            this.Controls.Add(this.lCiudad17);
            this.Controls.Add(this.lCiudad14);
            this.Controls.Add(this.lCiudad10);
            this.Controls.Add(this.lCiudad21);
            this.Controls.Add(this.lCiudad22);
            this.Controls.Add(this.lCiudad20);
            this.Controls.Add(this.lCiudad25);
            this.Controls.Add(this.lCiudad26);
            this.Controls.Add(this.lCiudad27);
            this.Controls.Add(this.lCiudad28);
            this.Controls.Add(this.lCiudad23);
            this.Controls.Add(this.lCiudad1);
            this.Controls.Add(this.lCiudad24);
            this.Controls.Add(this.lCiudad12);
            this.Controls.Add(this.lCiudad7);
            this.Controls.Add(this.lCiudad9);
            this.Controls.Add(this.lCiudad11);
            this.Controls.Add(this.lCiudad4);
            this.Controls.Add(this.lCiudad13);
            this.Controls.Add(this.lCiudad19);
            this.Controls.Add(this.lCiudad18);
            this.Controls.Add(this.lCiudad34);
            this.Controls.Add(this.lCiudad33);
            this.Controls.Add(this.lCiudad29);
            this.Controls.Add(this.lCiudad30);
            this.Controls.Add(this.lCiudad31);
            this.Controls.Add(this.lCiudad32);
            this.Controls.Add(this.lCiudad8);
            this.Controls.Add(this.lCiudad6);
            this.Controls.Add(this.lCiudad5);
            this.Controls.Add(this.lCiudad3);
            this.Controls.Add(this.lCiudad37);
            this.Controls.Add(this.lCiudad38);
            this.Controls.Add(this.lCiudad2);
            this.Controls.Add(this.lCiudad39);
            this.Controls.Add(this.lCiudad40);
            this.Controls.Add(this.lCiudad41);
            this.Controls.Add(this.lCiudad43);
            this.Controls.Add(this.lCiudad42);
            this.Controls.Add(this.lCiudad36);
            this.Controls.Add(this.lCiudad35);
            this.Controls.Add(this.lCiudad0);
            this.Controls.Add(this.Recorrido);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Ciudad22);
            this.Controls.Add(this.Ciudad26);
            this.Controls.Add(this.Ciudad28);
            this.Controls.Add(this.Ciudad27);
            this.Controls.Add(this.Ciudad25);
            this.Controls.Add(this.Ciudad23);
            this.Controls.Add(this.Ciudad24);
            this.Controls.Add(this.Ciudad20);
            this.Controls.Add(this.Ciudad18);
            this.Controls.Add(this.Ciudad19);
            this.Controls.Add(this.Ciudad32);
            this.Controls.Add(this.Ciudad31);
            this.Controls.Add(this.Ciudad30);
            this.Controls.Add(this.Ciudad29);
            this.Controls.Add(this.Ciudad33);
            this.Controls.Add(this.Ciudad34);
            this.Controls.Add(this.Ciudad38);
            this.Controls.Add(this.Ciudad39);
            this.Controls.Add(this.Ciudad40);
            this.Controls.Add(this.Ciudad41);
            this.Controls.Add(this.Ciudad43);
            this.Controls.Add(this.Ciudad42);
            this.Controls.Add(this.Ciudad35);
            this.Controls.Add(this.Ciudad36);
            this.Controls.Add(this.Ciudad37);
            this.Controls.Add(this.Ciudad21);
            this.Controls.Add(this.Ciudad17);
            this.Controls.Add(this.Ciudad16);
            this.Controls.Add(this.Ciudad15);
            this.Controls.Add(this.Ciudad14);
            this.Controls.Add(this.Ciudad12);
            this.Controls.Add(this.Ciudad10);
            this.Controls.Add(this.Ciudad8);
            this.Controls.Add(this.Ciudad7);
            this.Controls.Add(this.Ciudad9);
            this.Controls.Add(this.Ciudad13);
            this.Controls.Add(this.Ciudad11);
            this.Controls.Add(this.Ciudad4);
            this.Controls.Add(this.Ciudad5);
            this.Controls.Add(this.Ciudad3);
            this.Controls.Add(this.Ciudad2);
            this.Controls.Add(this.Ciudad6);
            this.Controls.Add(this.Ciudad1);
            this.Controls.Add(this.Ciudad0);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Origen);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ejemplo2);
            this.Controls.Add(this.Ejemplo1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Proyecto";
            this.Text = "Proyecto";
            this.Load += new System.EventHandler(this.Proyecto_Load);
            this.MouseLeave += new System.EventHandler(this.Global_MouseLeave);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Global_MouseMove);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ejemplo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ejemplo2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox Ejemplo1;
        private System.Windows.Forms.PictureBox Ejemplo2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Origen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Ciudad0;
        private System.Windows.Forms.Button Ciudad1;
        private System.Windows.Forms.Button Ciudad6;
        private System.Windows.Forms.Button Ciudad2;
        private System.Windows.Forms.Button Ciudad3;
        private System.Windows.Forms.Button Ciudad5;
        private System.Windows.Forms.Button Ciudad4;
        private System.Windows.Forms.Button Ciudad11;
        private System.Windows.Forms.Button Ciudad13;
        private System.Windows.Forms.Button Ciudad9;
        private System.Windows.Forms.Button Ciudad7;
        private System.Windows.Forms.Button Ciudad8;
        private System.Windows.Forms.Button Ciudad10;
        private System.Windows.Forms.Button Ciudad12;
        private System.Windows.Forms.Button Ciudad14;
        private System.Windows.Forms.Button Ciudad15;
        private System.Windows.Forms.Button Ciudad16;
        private System.Windows.Forms.Button Ciudad17;
        private System.Windows.Forms.Button Ciudad21;
        private System.Windows.Forms.Button Ciudad37;
        private System.Windows.Forms.Button Ciudad36;
        private System.Windows.Forms.Button Ciudad35;
        private System.Windows.Forms.Button Ciudad42;
        private System.Windows.Forms.Button Ciudad43;
        private System.Windows.Forms.Button Ciudad41;
        private System.Windows.Forms.Button Ciudad40;
        private System.Windows.Forms.Button Ciudad39;
        private System.Windows.Forms.Button Ciudad38;
        private System.Windows.Forms.Button Ciudad34;
        private System.Windows.Forms.Button Ciudad33;
        private System.Windows.Forms.Button Ciudad29;
        private System.Windows.Forms.Button Ciudad30;
        private System.Windows.Forms.Button Ciudad31;
        private System.Windows.Forms.Button Ciudad32;
        private System.Windows.Forms.Button Ciudad19;
        private System.Windows.Forms.Button Ciudad18;
        private System.Windows.Forms.Button Ciudad20;
        private System.Windows.Forms.Button Ciudad24;
        private System.Windows.Forms.Button Ciudad23;
        private System.Windows.Forms.Button Ciudad25;
        private System.Windows.Forms.Button Ciudad27;
        private System.Windows.Forms.Button Ciudad28;
        private System.Windows.Forms.Button Ciudad26;
        private System.Windows.Forms.Button Ciudad22;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox Recorrido;
        private System.Windows.Forms.Label lCiudad0;
        private System.Windows.Forms.Label lCiudad35;
        private System.Windows.Forms.Label lCiudad36;
        private System.Windows.Forms.Label lCiudad42;
        private System.Windows.Forms.Label lCiudad43;
        private System.Windows.Forms.Label lCiudad41;
        private System.Windows.Forms.Label lCiudad40;
        private System.Windows.Forms.Label lCiudad39;
        private System.Windows.Forms.Label lCiudad2;
        private System.Windows.Forms.Label lCiudad38;
        private System.Windows.Forms.Label lCiudad37;
        private System.Windows.Forms.Label lCiudad3;
        private System.Windows.Forms.Label lCiudad5;
        private System.Windows.Forms.Label lCiudad6;
        private System.Windows.Forms.Label lCiudad8;
        private System.Windows.Forms.Label lCiudad32;
        private System.Windows.Forms.Label lCiudad31;
        private System.Windows.Forms.Label lCiudad30;
        private System.Windows.Forms.Label lCiudad29;
        private System.Windows.Forms.Label lCiudad33;
        private System.Windows.Forms.Label lCiudad34;
        private System.Windows.Forms.Label lCiudad18;
        private System.Windows.Forms.Label lCiudad19;
        private System.Windows.Forms.Label lCiudad13;
        private System.Windows.Forms.Label lCiudad4;
        private System.Windows.Forms.Label lCiudad11;
        private System.Windows.Forms.Label lCiudad9;
        private System.Windows.Forms.Label lCiudad7;
        private System.Windows.Forms.Label lCiudad12;
        private System.Windows.Forms.Label lCiudad24;
        private System.Windows.Forms.Label lCiudad1;
        private System.Windows.Forms.Label lCiudad23;
        private System.Windows.Forms.Label lCiudad28;
        private System.Windows.Forms.Label lCiudad27;
        private System.Windows.Forms.Label lCiudad26;
        private System.Windows.Forms.Label lCiudad25;
        private System.Windows.Forms.Label lCiudad20;
        private System.Windows.Forms.Label lCiudad22;
        private System.Windows.Forms.Label lCiudad21;
        private System.Windows.Forms.Label lCiudad10;
        private System.Windows.Forms.Label lCiudad14;
        private System.Windows.Forms.Label lCiudad17;
        private System.Windows.Forms.Label lCiudad15;
        private System.Windows.Forms.Label lCiudad16;
    }
}