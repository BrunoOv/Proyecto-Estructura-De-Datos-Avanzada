﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml; 

namespace EditordeGrafos
{
    public partial class Euler : Form
    {
        /*Aristas Visitadas*/
        public List<Edge> circuito = new List<Edge>();
        /*Nodos Visitados por las aristas se pueden repetir */
        public List<NodeP> nodosRecorridos = new List<NodeP>();
        Graph graph;
        public Euler(Graph graph)
        {
            InitializeComponent();
            this.graph = graph;
            labelRecorrido.Text = labelRecorridoMain.Text = string.Empty;
            graph.UnselectAllEdges();
            NodeP inicio = new NodeP();
            if (EsCircuito())//Checamos si es un circuito
            {
                inicio = ObtenNodoInicial();
                CircuitoEuleriano(inicio, inicio, false);
                imprimeCircuito();
            }
            else if (EsCamino())//Checamos si es un camino
            {
                inicio = ObtenNodoInicial();
                CaminoElueriano(inicio);
                if(nodosRecorridos.Count == 1)
                {
                    nodosRecorridos.Clear();
                    caminoAux(graph[0], new List<(string o, string d)>());
                }
                imprimeCamino();
            }
            else//no es nada
            {
                MessageBox.Show("No tiene circuito ni camino");
            }
        }
        /*Busqueda del circuito*/
        private bool CircuitoEuleriano(NodeP OG, NodeP w, bool foundOG)
        {
            Edge camino = new Edge();
            nodosRecorridos.Add(w);
            foreach (NodeR r in w.relations)
            {
                camino = graph.GetEdge(w, r.Up);
                if (camino.Visited == false)
                {
                    camino.Visited = true;
                    circuito.Add(camino);
                    foundOG = CircuitoEuleriano(OG, r.Up, foundOG);
                    if (circuito.Count != graph.edgesList.Count)
                    {
                        circuito.Remove(camino);
                        nodosRecorridos.RemoveAt(nodosRecorridos.Count - 1);
                        camino.Visited = false;
                        foundOG = false;
                    }
                    else
                    {
                        if (foundOG == false)
                        {
                            circuito.Remove(camino);
                            nodosRecorridos.Remove(w);
                            camino.Visited = false;
                        }
                        return foundOG;
                    }
                }
            }
            if (w == OG) { foundOG = true; } else { nodosRecorridos.Remove(w); }

            return foundOG;
        }

        /*Busqueda del camino */
        private void CaminoElueriano(NodeP w)
        {
            Edge camino = new Edge();
            nodosRecorridos.Add(w);
            foreach (NodeR r in w.relations)
            {
                camino = graph.GetEdge(w, r.Up);
                if (camino.Visited == false)
                {
                    camino.Visited = true;
                    circuito.Add(camino);
                    CaminoElueriano(r.Up);
                    if (circuito.Count != graph.edgesList.Count)
                    {
                        circuito.Remove(camino);
                        nodosRecorridos.RemoveAt(nodosRecorridos.Count - 1);
                        camino.Visited = false;
                    }
                    else
                    {
                        return;
                    }
                }
            }
        }

        /*Para saber en que nodo iniciar  */
        private NodeP ObtenNodoInicial()
        {
            NodeP inicial = new NodeP();
            int gradoBase = 0;
            foreach (NodeP p in graph)
            {
                if (graph.EdgeIsDirected == false)//por si es no dirigido
                {
                    if (p.Degree > gradoBase)
                    {
                        gradoBase = p.Degree;
                        inicial = p;
                    }
                }
                else//dirigido
                {
                    if ((p.DegreeEx - p.DegreeIn) % 2 != 0 && p.DegreeEx > p.DegreeIn)
                    {
                        inicial = p;
                        break;
                    }
                    else
                    {
                        var indices = graph.Select(x => x.relations.Count).ToList();
                        inicial = graph[indices.IndexOf(indices.Max())];
                    }

                }
            }

            return inicial;
        }

        /*Verificaciones de si es circuito o es camino*/
        private bool EsCircuito()
        {
            bool circuitoE = true;

            foreach (NodeP p in graph)
            {
                if (graph.EdgeIsDirected == false)//no dirigido
                {
                    if (p.Degree % 2 != 0)//pares todos
                    {
                        circuitoE = false;
                        break;
                    }
                }
                else//dirigido
                {
                    if ((p.DegreeEx - p.DegreeIn) % 2 != 0)
                    {
                        circuitoE = false;
                        break;
                    }
                }
            }

            return circuitoE;
        }

        private bool EsCamino()
        {
            bool caminoE = true;
            int countOddNodes = 0;

            foreach (NodeP p in graph)
            {
                if (graph.EdgeIsDirected == false)
                {
                    if (p.Degree % 2 != 0)
                    {
                        countOddNodes++;
                    }
                }
                else
                {
                    if ((p.DegreeEx - p.DegreeIn) % 2 != 0)
                    {
                        countOddNodes++;
                    }
                }
                if (countOddNodes == 2) { caminoE = true; } else { caminoE = false; }
            }

            return caminoE;
        }

        /*Printf de recorrido*/
        public void imprimeCircuito()
        {
            List<string> aux = new List<string>();
            for (int i = 0; i < nodosRecorridos.Count; i++) { aux.Add(nodosRecorridos[i].Name); }
            var msn = string.Join(" -> ", aux);
            labelRecorridoMain.Text = "Es un Circuito";
            labelRecorrido.Text = msn;
        }

        public void imprimeCamino()
        {
            List<string> aux = new List<string>();
            for (int i = 0; i < nodosRecorridos.Count; i++) { aux.Add(nodosRecorridos[i].Name); }
            var msn = string.Join(" -> ", aux);
            labelRecorridoMain.Text = "Es un Camino";
            labelRecorrido.Text = msn;
        }
        
        private void caminoAux(NodeP nodeP,List<(string o, string d)> visitados)
        {
            var list = nodeP.relations.Select(x => x.Up).OrderBy(x => x.Name);
            nodosRecorridos.Add(nodeP);
            foreach (var d in list)
            {
                var edge = (nodeP.Name, d.Name);
                if (!visitados.Contains(edge))
                {
                    visitados.Add(edge);
                    if (!graph.EdgeIsDirected)
                        visitados.Add((d.Name, nodeP.Name));
                    caminoAux(d, visitados);
                }
            }
        }

    }
}
