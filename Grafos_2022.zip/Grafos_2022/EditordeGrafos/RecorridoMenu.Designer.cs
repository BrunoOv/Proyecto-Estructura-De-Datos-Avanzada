﻿namespace EditordeGrafos
{
    partial class RecorridoMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bttProfun = new System.Windows.Forms.Button();
            this.bttAmpli = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ComponenteNoDirjido = new System.Windows.Forms.Button();
            this.Euler = new System.Windows.Forms.Button();
            this.bttDijstra = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bttProfun
            // 
            this.bttProfun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bttProfun.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttProfun.Location = new System.Drawing.Point(185, 38);
            this.bttProfun.Name = "bttProfun";
            this.bttProfun.Size = new System.Drawing.Size(146, 46);
            this.bttProfun.TabIndex = 0;
            this.bttProfun.Text = "Profundidad";
            this.bttProfun.UseVisualStyleBackColor = false;
            this.bttProfun.Click += new System.EventHandler(this.bttProfun_Click);
            // 
            // bttAmpli
            // 
            this.bttAmpli.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bttAmpli.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttAmpli.Location = new System.Drawing.Point(12, 38);
            this.bttAmpli.Name = "bttAmpli";
            this.bttAmpli.Size = new System.Drawing.Size(149, 46);
            this.bttAmpli.TabIndex = 1;
            this.bttAmpli.Text = "Amplitud";
            this.bttAmpli.UseVisualStyleBackColor = false;
            this.bttAmpli.Click += new System.EventHandler(this.bttAmpli_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(91, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Es un grafo : ";
            // 
            // ComponenteNoDirjido
            // 
            this.ComponenteNoDirjido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ComponenteNoDirjido.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComponenteNoDirjido.Location = new System.Drawing.Point(185, 90);
            this.ComponenteNoDirjido.Name = "ComponenteNoDirjido";
            this.ComponenteNoDirjido.Size = new System.Drawing.Size(146, 79);
            this.ComponenteNoDirjido.TabIndex = 3;
            this.ComponenteNoDirjido.Text = "Componentes Conectados No Dirijidos";
            this.ComponenteNoDirjido.UseVisualStyleBackColor = false;
            this.ComponenteNoDirjido.Click += new System.EventHandler(this.ComponenteNoDirjido_Click);
            // 
            // Euler
            // 
            this.Euler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Euler.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Euler.Location = new System.Drawing.Point(15, 90);
            this.Euler.Name = "Euler";
            this.Euler.Size = new System.Drawing.Size(146, 79);
            this.Euler.TabIndex = 4;
            this.Euler.Text = "Euler";
            this.Euler.UseVisualStyleBackColor = false;
            this.Euler.Click += new System.EventHandler(this.Euler_Click);
            // 
            // bttDijstra
            // 
            this.bttDijstra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.bttDijstra.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttDijstra.Location = new System.Drawing.Point(15, 184);
            this.bttDijstra.Name = "bttDijstra";
            this.bttDijstra.Size = new System.Drawing.Size(146, 79);
            this.bttDijstra.TabIndex = 5;
            this.bttDijstra.Text = "Dijkstra";
            this.bttDijstra.UseVisualStyleBackColor = false;
            this.bttDijstra.Click += new System.EventHandler(this.bttDijstra_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button1.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(190, 184);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 79);
            this.button1.TabIndex = 6;
            this.button1.Text = "Prim";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RecorridoMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bttDijstra);
            this.Controls.Add(this.Euler);
            this.Controls.Add(this.ComponenteNoDirjido);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bttAmpli);
            this.Controls.Add(this.bttProfun);
            this.Name = "RecorridoMenu";
            this.Text = "Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttProfun;
        private System.Windows.Forms.Button bttAmpli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ComponenteNoDirjido;
        private System.Windows.Forms.Button Euler;
        private System.Windows.Forms.Button bttDijstra;
        private System.Windows.Forms.Button button1;
    }
}