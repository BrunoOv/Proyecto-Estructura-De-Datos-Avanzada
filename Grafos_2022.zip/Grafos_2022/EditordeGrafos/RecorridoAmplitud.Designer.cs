﻿namespace EditordeGrafos
{
    partial class RecorridoAmplitud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxRaiz = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RecorridoPrintf = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Seleccione una raiz:";
            // 
            // comboBoxRaiz
            // 
            this.comboBoxRaiz.FormattingEnabled = true;
            this.comboBoxRaiz.Location = new System.Drawing.Point(166, 9);
            this.comboBoxRaiz.Name = "comboBoxRaiz";
            this.comboBoxRaiz.Size = new System.Drawing.Size(121, 21);
            this.comboBoxRaiz.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Recorrido :";
            // 
            // RecorridoPrintf
            // 
            this.RecorridoPrintf.AutoSize = true;
            this.RecorridoPrintf.BackColor = System.Drawing.Color.MistyRose;
            this.RecorridoPrintf.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RecorridoPrintf.Location = new System.Drawing.Point(105, 47);
            this.RecorridoPrintf.Name = "RecorridoPrintf";
            this.RecorridoPrintf.Size = new System.Drawing.Size(60, 17);
            this.RecorridoPrintf.TabIndex = 3;
            this.RecorridoPrintf.Text = "Raiz ( ) ";
            // 
            // RecorridoAmplitud
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 450);
            this.Controls.Add(this.RecorridoPrintf);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxRaiz);
            this.Controls.Add(this.label1);
            this.Name = "RecorridoAmplitud";
            this.Text = "Amplitud";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxRaiz;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label RecorridoPrintf;
    }
}