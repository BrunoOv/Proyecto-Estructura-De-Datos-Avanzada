﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EditordeGrafos
{
    public partial class RecorridoProfundidad : Form
    {
        /*Para recorrido en profundidad*/
        NodeP raizActual = null;
        Graph grafo = null;

        public RecorridoProfundidad(Graph graph)
        {
            grafo = graph;
            InitializeComponent();
            Raices(grafo);

            comboBoxRaices.SelectedIndexChanged += comboBoxRaices_SelectedIndexChanged;
        }
        //Obtenemos todos los nodos del grafo para meterlos al combobox 
        public void Raices(Graph graph)
        {
            for (int i = 0; i < graph.Count; i++)
            {
                comboBoxRaices.Items.Add(graph[i].Name);
            }
        }
        //Cuando se seleccione una raiz empieza el recorrido apartir de esa raiz
        public void comboBoxRaices_SelectedIndexChanged(object sender, EventArgs e)
        {
            raizActual = grafo.ElementAt(comboBoxRaices.SelectedIndex);
            RecorridaProfundidadBosque(grafo, raizActual);
        }
        //Recorrido Profundidad Bosque
        public void RecorridaProfundidadBosque(Graph graph, NodeP raizActual)
        {
            RecorridoPrintf.Text = "";
            var visitados = new List<NodeP>();
            bool NoBinario = false;
            do
            {
                RecorridoPrintf.Text += "Raiz ( "+raizActual.Name+" ) ";
                NoBinario = ProfundidadRecursivo(grafo, raizActual, visitados);
                /*En la lista de nodos de grafo, obtiene el primero que no a sido visitado*/
                raizActual = grafo.Except(visitados).FirstOrDefault();
                RecorridoPrintf.Text += "\n";//salto de linea para la siguiente raiz
                if (NoBinario)//un nodo tiene mas de dos hijos
                {
                    RecorridoPrintf.Text = "Elije otra raiz\nRaiz ( )";
                    break;
                }
            } while (raizActual != null && !NoBinario);
            
        }
        //Recorrido Profundida Arbol
        bool ProfundidadRecursivo(Graph grafo, NodeP NodoRaiz, List<NodeP> visitados)
        {
            int bin = 0;
            NodoRaiz.OrdenaRelacion(NodoRaiz);
            visitados.Add(NodoRaiz);
            if (!RecorridoPrintf.Text.Contains(NodoRaiz.Name)) 
            {
                RecorridoPrintf.Text += " "+NodoRaiz.Name +" ";
            }
            foreach (NodeR nodoActual in NodoRaiz.relations)
            {
                var nodoHijo = nodoActual.Up;
                if (!visitados.Contains(nodoHijo))//No fue visitado
                {
                    if (ProfundidadRecursivo(grafo, nodoHijo, visitados))//visitamos profundamente
                    {
                        return true;
                    }
                    bin++;//cuantos nodos hijos lleva un nodo
                }
            }
            if (bin > 2)//si el nodo tiene mas de 2 hijos tns no es binario
            {
                return true;
            }
            return false;
        }
    }

}
