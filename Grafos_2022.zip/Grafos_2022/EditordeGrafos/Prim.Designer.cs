﻿namespace EditordeGrafos
{
    partial class Prim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBoxRaiz = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.recorridoLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBoxRaiz
            // 
            this.comboBoxRaiz.FormattingEnabled = true;
            this.comboBoxRaiz.Location = new System.Drawing.Point(136, 21);
            this.comboBoxRaiz.Name = "comboBoxRaiz";
            this.comboBoxRaiz.Size = new System.Drawing.Size(121, 21);
            this.comboBoxRaiz.TabIndex = 1;
            this.comboBoxRaiz.SelectedIndexChanged += new System.EventHandler(this.comboBoxRaiz_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.PeachPuff;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Elije un nodo:";
            // 
            // recorridoLabel
            // 
            this.recorridoLabel.AutoSize = true;
            this.recorridoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recorridoLabel.ForeColor = System.Drawing.Color.MidnightBlue;
            this.recorridoLabel.Location = new System.Drawing.Point(15, 52);
            this.recorridoLabel.Name = "recorridoLabel";
            this.recorridoLabel.Size = new System.Drawing.Size(73, 16);
            this.recorridoLabel.TabIndex = 3;
            this.recorridoLabel.Text = "Recorrido: ";
            // 
            // Prim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 149);
            this.Controls.Add(this.recorridoLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxRaiz);
            this.Name = "Prim";
            this.Text = "Prim";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBoxRaiz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label recorridoLabel;
    }
}