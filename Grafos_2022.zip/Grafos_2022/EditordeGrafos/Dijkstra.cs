﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TreeView;

namespace EditordeGrafos
{
    public partial class Dijkstra : Form
    {
        NodeP raizActual;
        Graph grafo;
        NodeP o;
        string caminominimo;
        int totalMinimo=int.MaxValue;
        Dictionary<NodeP, Tuple<string, NodeP>> DistanciayNodoAnterior = new Dictionary<NodeP, Tuple<string, NodeP>>();
        List<List<string>> vectorRelacionCambios = new List<List<string>>();
        private const string inf = "∞";

        public Dijkstra(Graph graph)
        {
            InitializeComponent();
            grafo = graph;
            Raices(grafo);
        }

        // Obtenemos todos los nodos del grafo para meterlos al ComboBox
        public void Raices(Graph graph)
        {
            for (int i = 0; i < graph.Count; i++)
            {
                comboBoxRaiz.Items.Add(graph[i].Name);
            }
        }

        // Cuando se seleccione una raíz, empieza la búsqueda del camino más corto
        public void comboBoxRaiz_SelectedIndexChanged(object sender, EventArgs e)
        {
            caminominimo = "";
            raizActual = grafo.ElementAt(comboBoxRaiz.SelectedIndex);
            o = raizActual;
            totalMinimo = int.MaxValue;
            DistanciayNodoAnterior = new Dictionary<NodeP, Tuple<string, NodeP>>();
            vectorRelacionCambios = new List<List<string>>();
            VectorOriginal.Rows.Clear();
            VectorFin.Rows.Clear();
            DijkstraN(raizActual);
            if (caminominimo.Count()>1) {
                if (caminominimo.Count() > 15)
                {
                    caminominimo += "\nUsa intermedios";
                }
                else
                {
                    caminominimo += "\nFue directo";
                } 
            }
            SecuenciaMinima.Text = caminominimo;
        }

        // Algoritmo Dijkstra
        public void DijkstraN(NodeP actual)
        {
            HashSet<NodeP> nodosVisitados = new HashSet<NodeP>();

            foreach (var nodo in grafo)
            {
                DistanciayNodoAnterior[nodo] = new Tuple<string, NodeP>(inf, null);
            }

            DistanciayNodoAnterior[actual] = new Tuple<string, NodeP>("0", null);

            List<string> vectorRelacionOriginal = new List<string>();


            foreach (var nodo in grafo)
            {
                vectorRelacionOriginal.Add(DistanciayNodoAnterior[nodo].Item1);
            }

            vectorRelacionCambios.Add(vectorRelacionOriginal);

            while (true)
            {
                NodeP nodoMinimo = null;
                string distanciaMinima = inf;

                // Encuentra el nodo con la distancia mínima no visitado
                foreach (var nodo in grafo)
                {
                    if (!nodosVisitados.Contains(nodo) && string.Compare(DistanciayNodoAnterior[nodo].Item1, distanciaMinima) < 0)
                    {
                        nodoMinimo = nodo;
                        distanciaMinima = DistanciayNodoAnterior[nodo].Item1;
                    }
                }

                if (nodoMinimo == null)
                {
                    // Todos los nodos han sido visitados
                    break;
                }

                nodosVisitados.Add(nodoMinimo);

                foreach (var relacion in nodoMinimo.relations)
                {
                    NodeP vecino = relacion.Up;
                    if (!nodosVisitados.Contains(vecino))
                    {
                        Edge arista = grafo.GetEdge(nodoMinimo, vecino);
                        if (arista != null)
                        {
                            int distanciaActual = int.Parse(DistanciayNodoAnterior[nodoMinimo].Item1);
                            int distanciaPosible = distanciaActual + arista.Weight;

                            if (DistanciayNodoAnterior[vecino].Item1 == inf)
                            {
                                DistanciayNodoAnterior[vecino] = new Tuple<string, NodeP>(distanciaPosible.ToString(), nodoMinimo);
                            }
                            else
                            {
                                int distanciaGuardada = int.Parse(DistanciayNodoAnterior[vecino].Item1);

                                if (distanciaPosible < distanciaGuardada)
                                {
                                    DistanciayNodoAnterior[vecino] = new Tuple<string, NodeP>(distanciaPosible.ToString(), nodoMinimo);
                                }
                            }


                        }
                    }
                }

                //Agregamos cambios de iteracion
                List<string> vectorRelacionCambio = new List<string>();
                foreach (var nodo in grafo)
                {
                    vectorRelacionCambio.Add(DistanciayNodoAnterior[nodo].Item1);
                }
                vectorRelacionCambios.Add(vectorRelacionCambio);
            }
            ParesDeNodos.Items.Clear();
            foreach (var nodo in grafo)
            {
                imprime1(nodo); 
            }
            imprime2();
        }

        public void imprime1(NodeP nodoFinal)
        {
            NodeP nodoActual = nodoFinal;
            List<string> camino = new List<string>();
            List<int> costos = new List<int>();
            while (nodoActual != null)
            {
                if (DistanciayNodoAnterior[nodoActual].Item2 != null)
                {
                    string par = "[" + DistanciayNodoAnterior[nodoActual].Item2.Name + ", " + nodoActual.Name + "]";
                    int costoActual = int.Parse(DistanciayNodoAnterior[nodoActual].Item1);
                    int costoAnterior = int.Parse(DistanciayNodoAnterior[DistanciayNodoAnterior[nodoActual].Item2].Item1);
                    int costo = costoActual - costoAnterior;
                    costos.Add(costo);
                    camino.Insert(0, par);
                }
                nodoActual = DistanciayNodoAnterior[nodoActual].Item2;
            }
            string caminoCompleto = string.Join(" ", camino);
            caminoCompleto += " = ";
            int total=0;
            int i = 0;
            foreach (var c in costos)
            {
                caminoCompleto += c;
                i++;
                if (i<costos.Count)
                {
                caminoCompleto += " + ";
                } 
                total += c;
            }
            if (i > 1)
            {
                caminoCompleto += " = " + total;
            }
           
            if (camino.Count > 0)
            {
                ParesDeNodos.Items.Add(caminoCompleto);
                if (totalMinimo > total)
                {
                    caminominimo = caminoCompleto;
                    totalMinimo = total;
                }
            }
        }
        public void imprime2()
        {
            int iteracion = 0;
            VectorFin.Rows.Clear();
            VectorFin.Columns.Clear();
            VectorOriginal.Rows.Clear();
            VectorOriginal.Columns.Clear();
            VectorOriginal.Columns.Add("Inicio", "");
            VectorFin.Columns.Add("Inicio", "");
            for (int i = 0; i < vectorRelacionCambios[0].Count; i++)
            {
                VectorOriginal.Columns.Add("Columna" + i, grafo[i].Name);
                VectorFin.Columns.Add("Columna" + i, grafo[i].Name);
            }

            foreach (var vectorRelacion in vectorRelacionCambios)
            {
                if (iteracion == 1)//la de inicio
                {
                    VectorOriginal.Rows.Add();
                    VectorOriginal.Rows[0].Cells[0].Value = o.Name;

                    for (int i = 0; i < vectorRelacion.Count; i++)
                    {
                        VectorOriginal.Rows[0].Cells[i + 1].Value = vectorRelacion[i]; 
                    }
                }
                if (iteracion == vectorRelacionCambios.Count - 1)//la del final
                {
                    VectorFin.Rows.Add();
                    VectorFin.Rows[0].Cells[0].Value = o.Name;

                    for (int i = 0; i < vectorRelacion.Count; i++)
                    {
                        VectorFin.Rows[0].Cells[i + 1].Value = vectorRelacion[i]; 
                    }
                }
                iteracion++;
            }
        }

        
    }
    
}
