﻿namespace EditordeGrafos
{
    partial class Dijkstra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxRaiz = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SecuenciaMinima = new System.Windows.Forms.Label();
            this.VectorOriginal = new System.Windows.Forms.DataGridView();
            this.VectorFin = new System.Windows.Forms.DataGridView();
            this.ParesDeNodos = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.VectorOriginal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VectorFin)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(12, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(447, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "1) Esquema del Grafo con los pares [Nodo Anterior, Nodo Siguiente] de cada nodo +" +
    " Costos. ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(12, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(196, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "2) Vector Relación o de Costos (original)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(12, 231);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(392, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "3) Vectores con los cambios de las iteraciones en el Vector Relación o de Costos." +
    "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(12, 333);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(686, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "4) Secuencia de Nodos del Camino más Corto desde el Origen (al nodo de distancia " +
    "más corta) y 5) Costo del Camino más Corto desde el Origen";
            // 
            // comboBoxRaiz
            // 
            this.comboBoxRaiz.FormattingEnabled = true;
            this.comboBoxRaiz.Location = new System.Drawing.Point(137, 12);
            this.comboBoxRaiz.Name = "comboBoxRaiz";
            this.comboBoxRaiz.Size = new System.Drawing.Size(62, 21);
            this.comboBoxRaiz.TabIndex = 5;
            this.comboBoxRaiz.SelectedIndexChanged += new System.EventHandler(this.comboBoxRaiz_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.LightCoral;
            this.label6.Font = new System.Drawing.Font("MV Boli", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(19, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Elije un nodo :";
            // 
            // SecuenciaMinima
            // 
            this.SecuenciaMinima.AutoSize = true;
            this.SecuenciaMinima.Location = new System.Drawing.Point(25, 367);
            this.SecuenciaMinima.Name = "SecuenciaMinima";
            this.SecuenciaMinima.Size = new System.Drawing.Size(67, 13);
            this.SecuenciaMinima.TabIndex = 10;
            this.SecuenciaMinima.Text = "Esperando...";
            // 
            // VectorOriginal
            // 
            this.VectorOriginal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VectorOriginal.Location = new System.Drawing.Point(28, 149);
            this.VectorOriginal.Name = "VectorOriginal";
            this.VectorOriginal.Size = new System.Drawing.Size(801, 69);
            this.VectorOriginal.TabIndex = 12;
            // 
            // VectorFin
            // 
            this.VectorFin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VectorFin.Location = new System.Drawing.Point(28, 247);
            this.VectorFin.Name = "VectorFin";
            this.VectorFin.Size = new System.Drawing.Size(801, 68);
            this.VectorFin.TabIndex = 13;
            // 
            // ParesDeNodos
            // 
            this.ParesDeNodos.FormattingEnabled = true;
            this.ParesDeNodos.Location = new System.Drawing.Point(28, 58);
            this.ParesDeNodos.Name = "ParesDeNodos";
            this.ParesDeNodos.Size = new System.Drawing.Size(801, 69);
            this.ParesDeNodos.TabIndex = 14;
            // 
            // Dijkstra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 408);
            this.Controls.Add(this.ParesDeNodos);
            this.Controls.Add(this.VectorFin);
            this.Controls.Add(this.VectorOriginal);
            this.Controls.Add(this.SecuenciaMinima);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBoxRaiz);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Dijkstra";
            this.Text = "Dijkstra";
            ((System.ComponentModel.ISupportInitialize)(this.VectorOriginal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VectorFin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxRaiz;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label SecuenciaMinima;
        private System.Windows.Forms.DataGridView VectorOriginal;
        private System.Windows.Forms.DataGridView VectorFin;
        private System.Windows.Forms.ListBox ParesDeNodos;
    }
}