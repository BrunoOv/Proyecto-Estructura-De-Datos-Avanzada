﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditordeGrafos
{
    public class Root
    {

        public List<long> list_TreeContent;

        public List<long> list_Itermedia;


        public Root()
        { }



    }
}
