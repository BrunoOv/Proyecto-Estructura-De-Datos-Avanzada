﻿namespace EditordeGrafos
{
    partial class muestraGrados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.muestraGradosIn = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.muestraGradosSalida = new System.Windows.Forms.TextBox();
            this.gradoTotalG = new System.Windows.Forms.TextBox();
            this.textNodoEspecial = new System.Windows.Forms.TextBox();
            this.muestraNodosEspeciales = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(111, 20);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "Grados de entrada: ";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // muestraGradosIn
            // 
            this.muestraGradosIn.Location = new System.Drawing.Point(12, 38);
            this.muestraGradosIn.Multiline = true;
            this.muestraGradosIn.Name = "muestraGradosIn";
            this.muestraGradosIn.Size = new System.Drawing.Size(111, 160);
            this.muestraGradosIn.TabIndex = 6;
            this.muestraGradosIn.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(152, 12);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(106, 20);
            this.textBox3.TabIndex = 7;
            this.textBox3.Text = "Grados de salida: ";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // muestraGradosSalida
            // 
            this.muestraGradosSalida.Location = new System.Drawing.Point(152, 38);
            this.muestraGradosSalida.Multiline = true;
            this.muestraGradosSalida.Name = "muestraGradosSalida";
            this.muestraGradosSalida.Size = new System.Drawing.Size(106, 160);
            this.muestraGradosSalida.TabIndex = 8;
            this.muestraGradosSalida.TextChanged += new System.EventHandler(this.muestraGradosSalida_TextChanged);
            // 
            // gradoTotalG
            // 
            this.gradoTotalG.Location = new System.Drawing.Point(12, 215);
            this.gradoTotalG.Name = "gradoTotalG";
            this.gradoTotalG.Size = new System.Drawing.Size(133, 20);
            this.gradoTotalG.TabIndex = 9;
            this.gradoTotalG.Text = "Grado Total del grafo: ";
            this.gradoTotalG.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gradoTotalG.TextChanged += new System.EventHandler(this.gradoTotalG_TextChanged);
            // 
            // textNodoEspecial
            // 
            this.textNodoEspecial.Location = new System.Drawing.Point(273, 12);
            this.textNodoEspecial.Name = "textNodoEspecial";
            this.textNodoEspecial.Size = new System.Drawing.Size(111, 20);
            this.textNodoEspecial.TabIndex = 10;
            this.textNodoEspecial.Text = "Nodos Especiales:";
            this.textNodoEspecial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // muestraNodosEspeciales
            // 
            this.muestraNodosEspeciales.Location = new System.Drawing.Point(273, 38);
            this.muestraNodosEspeciales.Multiline = true;
            this.muestraNodosEspeciales.Name = "muestraNodosEspeciales";
            this.muestraNodosEspeciales.Size = new System.Drawing.Size(111, 160);
            this.muestraNodosEspeciales.TabIndex = 11;
            // 
            // muestraGrados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.muestraNodosEspeciales);
            this.Controls.Add(this.textNodoEspecial);
            this.Controls.Add(this.gradoTotalG);
            this.Controls.Add(this.muestraGradosSalida);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.muestraGradosIn);
            this.Controls.Add(this.textBox1);
            this.Name = "muestraGrados";
            this.Text = "muestraGrados";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox muestraGradosIn;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox muestraGradosSalida;
        private System.Windows.Forms.TextBox gradoTotalG;
        private System.Windows.Forms.TextBox textNodoEspecial;
        private System.Windows.Forms.TextBox muestraNodosEspeciales;
    }
}