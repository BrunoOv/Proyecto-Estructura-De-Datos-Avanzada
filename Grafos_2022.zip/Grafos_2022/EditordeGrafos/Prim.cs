﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EditordeGrafos
{
    public partial class Prim : Form
    {
        Graph grafo;
        NodeP raizActual;
        int peso = 0;
        public Prim(Graph graph)
        {
            InitializeComponent();
            grafo = graph;
            Raices();

        }
        // Obtenemos todos los nodos del grafo para meterlos al ComboBox
        public void Raices()
        {
            for (int i = 0; i < grafo.Count; i++)
                comboBoxRaiz.Items.Add(grafo[i].Name);
        }
        // Cuando se seleccione una raíz, empieza la búsqueda del camino más corto
        public void comboBoxRaiz_SelectedIndexChanged(object sender, EventArgs e)
        {
            raizActual = grafo.ElementAt(comboBoxRaiz.SelectedIndex);
            peso = 0;
            imprime(primR(grafo, raizActual));
        }

        public List<NodeP> primR(Graph grafo, NodeP raiz)
        {
            List<NodeP> arbolEspancion = new List<NodeP>();
            Dictionary<NodeP, Tuple<int, NodeP>> DistanciaYAnterior = new Dictionary<NodeP, Tuple<int, NodeP>>();
            // Inicializo el diccionario
            foreach (NodeP nodo in grafo)
                DistanciaYAnterior[nodo] = Tuple.Create(int.MaxValue, (NodeP)null);
            
            // no importa donde empezamos
            DistanciaYAnterior[raiz] = Tuple.Create(0, raiz);
            //hasta que se visiten todos los nodos
            while (arbolEspancion.Count < grafo.Count)
            {
                NodeP nodoActual = null;
                int distanciaMinima = int.MaxValue;
                int acum = 0;
                foreach (NodeP nodo in grafo)
                {
                    if (!arbolEspancion.Contains(nodo) && DistanciaYAnterior[nodo].Item1 < distanciaMinima)
                    {
                        nodoActual = nodo;
                        distanciaMinima = DistanciaYAnterior[nodo].Item1;
                        acum = distanciaMinima;
                    }
                }
                if (nodoActual == null)
                {
                    break;
                }
                //agreamos al arbol y actualizamos el peso
                arbolEspancion.Add(nodoActual);
                peso += distanciaMinima;
                // Actualiza distancia y nodo 
                foreach (NodeR relacion in nodoActual.relations)
                {
                    NodeP nodoAdyacente = relacion.Up;
                    int pesoArista = grafo.GetEdge(nodoActual, nodoAdyacente).Weight;

                    if (!arbolEspancion.Contains(nodoAdyacente) && pesoArista < DistanciaYAnterior[nodoAdyacente].Item1)
                    {
                        DistanciaYAnterior[nodoAdyacente] = Tuple.Create(pesoArista, nodoActual);
                    }
                }
            }
            return arbolEspancion;
        }

        public void imprime(List<NodeP> arbol)
        {
            recorridoLabel.Text = "Recorrido: ";

            foreach (NodeP nodo in arbol)
                recorridoLabel.Text += nodo.Name + " ";
            
            recorridoLabel.Text += "\nPeso : " + peso;
        }
    }
}
