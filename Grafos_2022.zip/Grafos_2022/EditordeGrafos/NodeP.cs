﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*Son los atributos de un nodo */
namespace EditordeGrafos{
    [Serializable()]

    public class NodeP{
        private bool visited;/*Importate para recorridos*/
        private bool selected;
        private int degree;
        private int degreeIn;
        private int degreeEx;
        private string name; /// tomar este 
        private Point position;
        private Color color;
        public List<NodeR> relations;/*Con que nodos esta relacionado*/
       

        public Point Position { 
            get { return position; } 
            set { position = value; } 
        }

        public string Name {
            get { return name; } 
            set { name = value; } 
        }
        public int Degree {
            get { return degree; } 
            set { degree = value; } 
        }

        public Color Color{
            get { return color; } 
            set { color=value; }
        }

        public int DegreeIn {
            get { return degreeIn; } 
            set { degreeIn = value; } 
        }
        public int DegreeEx {
            get { return degreeEx; } 
            set { degreeEx = value; } 
        }
        public bool Selected{
            get { return selected; }
            set { selected=value; }
        }
        //no supe como implementar eso mas facil me parecio hacer una lista y meter los visitados
        public bool Visited { //Tenemos atributo que si ya esta visitado sirve para cuando hagamos recorridos
            get { return visited; } 
            set { visited = value; } 
        }

        #region constructores

        public NodeP(){

        }

        public NodeP(NodeP co){
            position = co.Position;
            name = co.Name;
            relations = new List<NodeR>();
            degree = co.Degree;
            degreeEx = co.DegreeEx;
            degreeIn = co.DegreeIn;
            color = co.Color;
            selected = false;
        }

        public NodeP(Point p, char n){
            position = p;
            name = n.ToString();
            relations = new List<NodeR>();
            degree = 0;
            color = Color.White;
            selected = false;
        }

        #endregion
        #region operaciones

        public void InsertRelation(NodeP newRel, int num, bool isDirected){
            Degree++;
            if(isDirected){
                DegreeEx++;
                newRel.DegreeIn++;
            }

            relations.Add(new NodeR(newRel, "e" + num.ToString()));
        }

        public void RemoveRelation(NodeR delRel, bool isDirected) {
            Degree--;
            if (isDirected) {
                delRel.Up.DegreeIn--;
                this.degreeEx--;
            }
            relations.Remove(delRel);
        }
        /*Ordena las relaciones de un nodo en especifico ascendente*/
        public void OrdenaRelacion(NodeP nodis)
        {
            int num1=0;
            if (int.TryParse(nodis.Name,out num1)) {//por si se llaman como numeros los nodos
                relations = relations.OrderBy(relacion => int.Parse(relacion.Up.Name)).ToList();
            }
            else {//por si se llaman con letras
                relations = relations.OrderBy(relacion => relacion.Up.Name).ToList();
            } 
        }
        /*Ordena las relaciones de un nodo en especifico decendente*/
        public void OrdenaRelacionInverso(NodeP nodis)
        {
            int num1 = 0;
            if (int.TryParse(nodis.Name, out num1))
            {//por si se llaman como numeros los nodos
                relations = relations.OrderByDescending(relacion => int.Parse(relacion.Up.Name)).ToList();
            }
            else
            {//por si se llaman con letras
                relations = relations.OrderByDescending(relacion => relacion.Up.Name).ToList();
            }
        }

        #endregion
    }
}
