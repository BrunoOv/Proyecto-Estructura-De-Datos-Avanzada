﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EditordeGrafos
{
    public partial class Arboles : Form
    {
        public string ext;
        public FileStream f;
        public int tam;
        public hojaB infoRoot;
        public bool flag = false;
        public bool inseetFlag = false;
        public int enterCount = 0;
        public List<int> numeros;
        public int degree = 5;
        public List<arbolBPlus> elements;
        public List<hojaB> hojas;
        public List<IntMed> intermedios;
        public List<Root> listaH;
        public List<long> nums;
        public string file;


        public Arboles()
        {

            InitializeComponent();
            hojas = new List<hojaB>();
            elements = new List<arbolBPlus>();
            nums = new List<long>();
            numeros = new List<int>();
            tam = 1000;
            NODO.Text += 30;
            Registro.Text += 65;

        }

        private void cierraArch(object sender, EventArgs e)
        {
            hojas = new List<hojaB>();
            elements = new List<arbolBPlus>();
            nums = new List<long>();
            infoRoot = null;
            tam = 1000;
            insertInfo();
            Raiz.Text = "";
            Raiz.Text += tam;
        }


        private void nuevoFile(object sender, EventArgs e)
        {
            cierraArch(null, null);

            SaveFileDialog saveDialog = new SaveFileDialog()
            {
                InitialDirectory = Path.Combine(Application.StartupPath, "ArbolB+"),
                Filter = "Archivos BIN (*.bin)|*.bin",
                DefaultExt = "bin"
            };

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                file = saveDialog.FileName;
                ext = Path.GetExtension(file);
                f = new FileStream(file, FileMode.Create, FileAccess.Write);
                nuevaPag('H');
                infoRoot = hojas.First();
                insertInfo();
                EndOfFile.Text = "";
                EndOfFile.Text += tam;
                f.Close();
            }
        }




        private void AbreArchivo(object sender, EventArgs e)
        {
            cierraArch(null, null);

            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Archivos de texto (*.txt)|*.txt";
            openDialog.InitialDirectory = Application.StartupPath + "\\ArbolB+";
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                flag = true;
                file = openDialog.FileName;
                ext = Path.GetExtension(openDialog.FileName);
                f = new FileStream(file, FileMode.Open, FileAccess.Read);
                nuevaPag('H');
                infoRoot = hojas.First();
                StreamReader sr;
                sr = new StreamReader(f);
                string texto = sr.ReadToEnd();
                texto.Trim(' ');
                string[] content = texto.Split(',');
                int aux = 0;
                foreach (string c in content)
                {
                    if (int.TryParse(c, out aux))
                    {
                        nuevoDato(aux);
                    }
                }
                f.Close();
                flag = false;
                EndOfFile.Text = "";
                EndOfFile.Text += tam;
                Raiz.Text = "";
                Raiz.Text += infoRoot.dir;

            }
        }

        private hojaB nuevaPag(char t)
        {
            hojaB nHoja = new hojaB(degree);
            nHoja.dir = tam;
            nHoja.tipo = t;
            nHoja.aux_Cuenta = enterCount;
            tam += 65;
            hojas.Add(nHoja);
            enterCount++;
            return nHoja;
        }

        private arbolBPlus guardaNum(int Num)
        {
            dato.Text = "";
            dato.Text += tam;

            arbolBPlus r = new arbolBPlus(Num);
            r.dir = tam;
            tam += 30;
            if (elements.Count > 0)
            {
                elements.Last().dir_sig = r.dir;
            }
            elements.Add(r);
            nums.Add(r.num);
            if (!flag)
            {
                StreamWriter sw;
                f = new FileStream(file, FileMode.Append, FileAccess.Write);
                sw = new StreamWriter(f);
                sw.Write(r.num.ToString() + ", ");
                sw.Flush();
                f.Close();
            }
            return r;
        }


        private void DivPag(hojaB Dato)
        {
            hojaB pM = nuevaPag(Dato.tipo);
            int aux_Cuenta = 0;
            foreach (var R in Dato.elementos)
            {
                if (Dato.tipo == 'H' || Dato.tipo == 'R')
                {
                    if (aux_Cuenta >= 2)
                    {
                        pM.elementos.Add(R);
                        pM.direcciones.Add(Dato.direcciones[aux_Cuenta]);
                        if (Dato.tipo == 'R' && Dato.elementos.Last() == R)
                        {
                            pM.direcciones.Add(Dato.direcciones[aux_Cuenta] + 1);
                        }
                    }
                }
                else
                {
                    if (aux_Cuenta >= 3)
                    {
                        pM.elementos.Add(R);
                        pM.direcciones.Add(Dato.direcciones[aux_Cuenta]);
                    }
                }
                aux_Cuenta++;
            }
            foreach (var R in pM.elementos)
            {
                if (Dato.elementos.Contains(R))
                {
                    Dato.elementos.Remove(R);
                }
            }
            foreach (var P in pM.direcciones)
            {
                if (Dato.direcciones.Contains(P))
                {
                    Dato.direcciones.Remove(P);
                }
            }
            if (Dato.tipo != 'R')
            {
                hojaB padre = obtenPadre(Dato.dir);
                nodoAInsertar(padre, pM);
            }
            else
            {
                divPag(pM);
            }
        }
        private void nodoAInsertar(hojaB nPa, hojaB nMy)
        {
            nPa.elementos.Add(nMy.elementos.First());
            nPa.elementos.Sort();
            nPa.direcciones.Insert(nPa.elementos.IndexOf(nMy.elementos.First()) + 1, nMy.dir);
            if (nMy.tipo != 'H')
            {
                nMy.elementos.Remove(nMy.elementos.First());
            }
            if (nPa.elementos.Count > degree - 1)
            {
                if (nPa.tipo != 'R')
                {
                    DivPag(nPa);
                }
                else
                {
                    divPag(nMy);
                }
            }
        }

        private hojaB obtenPadre(long dirHijo)
        {
            hojaB padre = null;
            foreach (var a in hojas)
            {
                if (a.direcciones.Contains(dirHijo))
                {
                    padre = a;
                    break;
                }
            }

            return padre;

        }
        private void nuevoDato(int Num)
        {
            if (!nums.Contains(Num))
            {
                arbolBPlus r = guardaNum(Num);
                if (infoRoot.tipo == 'H')
                {

                    infoRoot.elementos.Add(Num);
                    infoRoot.elementos.Sort();
                    infoRoot.direcciones.Insert(infoRoot.elementos.IndexOf(Num), r.dir);
                    if (infoRoot.elementos.Count > degree - 1)
                    {
                        dividir();
                        Raiz.Text = "";
                        Raiz.Text += infoRoot.dir;
                    }
                }

                else
                {
                    hojaB h = hoja(Num, infoRoot);
                    h.elementos.Add(Num);
                    h.elementos.Sort();
                    h.direcciones.Insert(h.elementos.IndexOf(Num), r.dir);
                    if (h.elementos.Count > degree - 1)
                    {
                        DivPag(h);
                    }
                }
                insertInfo();
            }
            else
            {
                MessageBox.Show("Dato Ya Insertado");
            }
        }
        private hojaB hoja(int num, hojaB actual)
        {
            hojaB aux = null;
            if (actual.tipo == 'H')
            {
                return actual;
            }
            else
            {
                foreach (var r in actual.elementos)
                {
                    if (num < r)
                    {
                        aux = hoja(num, obtenTipo(actual.direcciones[actual.elementos.IndexOf(r)]));
                        break;
                    }
                    else
                    {
                        if (actual.elementos.Last() == r)
                        {
                            aux = hoja(num, obtenTipo(actual.direcciones[actual.elementos.IndexOf(r) + 1]));
                            break;
                        }
                    }
                }

            }
            return aux;
        }
        private hojaB obtenTipo(long Direccion)
        {
            hojaB look = null;
            foreach (var a in hojas)
            {
                if (a.dir == Direccion)
                {
                    look = a;
                    break;
                }
            }
            return look;
        }
        public void dividir()
        {
            hojaB parienteM = nuevaPag('H');
            hojaB RaizPrincipal = nuevaPag('R');
            int aux_Cuenta = 0;
            foreach (var R in infoRoot.elementos)
            {
                if (aux_Cuenta >= 2)
                {
                    parienteM.elementos.Add(R);
                    parienteM.direcciones.Add(infoRoot.direcciones[aux_Cuenta]);
                }
                aux_Cuenta++;
            }
            foreach (var R in parienteM.elementos)
            {
                if (infoRoot.elementos.Contains(R))
                {
                    infoRoot.elementos.Remove(R);
                }
            }
            foreach (var P in parienteM.direcciones)
            {
                if (infoRoot.direcciones.Contains(P))
                {
                    infoRoot.direcciones.Remove(P);
                }
            }
            RaizPrincipal.elementos.Add(obtenIzq(parienteM));
            RaizPrincipal.direcciones.Add(infoRoot.dir);
            RaizPrincipal.direcciones.Add(parienteM.dir);
            infoRoot = RaizPrincipal;
            Raiz.Text = "";
            Raiz.Text += infoRoot.dir;
        }
        private void divPag(hojaB pM)
        {
            if (infoRoot.elementos.Count > degree - 1)
            {
                pM = nuevaPag('I');
                int aux_Cuenta = 0;
                foreach (var R in infoRoot.elementos)
                {
                    if (aux_Cuenta >= 2)
                    {

                        pM.elementos.Add(R);
                        pM.direcciones.Add(infoRoot.direcciones[aux_Cuenta + 1]);
                    }
                    aux_Cuenta++;
                }

                foreach (var R in pM.elementos)
                {
                    if (infoRoot.elementos.Contains(R))
                    {
                        infoRoot.elementos.Remove(R);
                    }
                }
                foreach (var P in pM.direcciones)
                {
                    if (infoRoot.direcciones.Contains(P))
                    {
                        infoRoot.direcciones.Remove(P);
                    }
                }
            }

            pM.tipo = 'I';

            hojaB RaizPrincipal = nuevaPag('R');
            RaizPrincipal.direcciones.Add(infoRoot.dir);
            nodoAInsertar(RaizPrincipal, pM);
            infoRoot.tipo = 'I';
            infoRoot = RaizPrincipal;
                Raiz.Text="";
               Raiz.Text += infoRoot.dir;

        }
        private long obtenIzq(hojaB Leaf)
        {
            long menor;
            menor = Leaf.elementos.First();
            return menor;
        }
        private void insertInfo()
        {
             Arbol.Rows.Clear();
            int contador = 0;
            foreach (var data in hojas)
            {
                DataGridViewRow fila = new DataGridViewRow();
                fila.Cells.Add(new DataGridViewTextBoxCell { Value = data.dir });
                fila.Cells.Add(new DataGridViewTextBoxCell { Value = data.tipo });
                foreach (var l in data.direcciones)
                {
                    fila.Cells.Add(new DataGridViewTextBoxCell { Value = l });
                    if (data.direcciones.IndexOf(l) < data.elementos.Count)
                    {
                        fila.Cells.Add(new DataGridViewTextBoxCell { Value = data.elementos[data.direcciones.IndexOf(l)] });
                    }
                    contador++;
                }
                if (contador <= degree - 1)
                {
                    if (data.tipo == 'H')
                    {
                        for (; contador < degree - 1; contador++)
                        {
                            fila.Cells.Add(new DataGridViewTextBoxCell { Value = "-1" });
                            fila.Cells.Add(new DataGridViewTextBoxCell { Value = "-1" });
                        }
                        fila.Cells.Add(new DataGridViewTextBoxCell { Value = "-1" });
                    }
                    else
                    {
                        for (; contador < degree; contador++)
                        {
                            fila.Cells.Add(new DataGridViewTextBoxCell { Value = "-1" });
                            fila.Cells.Add(new DataGridViewTextBoxCell { Value = "-1" });
                        }
                    }
                }
                   Arbol.Rows.Add(fila);
                contador = 0;
            }

            foreach (var data in elements)
            {
                Arbol.Rows.Add(data.dir, data.Tipo, data.dir_sig, data.num);
            }
            Arbol.Sort(Arbol.Columns[0], ListSortDirection.Ascending);
        }

        private void carga_arbol(object sender, EventArgs e)
        {
            inseetFlag = true;
            AbreArchivo(sender, e);
        }

        private void btnGuardaBin_Click(object sender, EventArgs e)
        {

            SaveFileDialog sfd = new SaveFileDialog();

            List<int> nums = new List<int>();
            long Direccionraiz = long.Parse(Raiz.Text);
            long texteOF = long.Parse(EndOfFile.Text);
            long Ultimoregistro = long.Parse(dato.Text);

            sfd.Filter = "Archivos binarios (*.bin)|*.bin";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                string fileName = sfd.FileName;

                using (FileStream fs = new FileStream(fileName, FileMode.Create))
                {




                    using (BinaryWriter writer = new BinaryWriter(fs))
                    {

                        writer.Write(Direccionraiz);
                        writer.Write(texteOF);
                        writer.Write(Ultimoregistro);



                        fs.Seek(1000, SeekOrigin.Begin);

                        for (int row = 0; row < Arbol.Rows.Count - 1; row++)
                        {
                            if (Arbol.Rows[row].Cells[1].Value.ToString() == "I" || Arbol.Rows[row].Cells[1].Value.ToString() == "R" || Arbol.Rows[row].Cells[1].Value.ToString() == "H")
                            {
                                
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[0].Value.ToString()));
                                writer.Write(char.Parse(Arbol.Rows[row].Cells[1].Value.ToString()));
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[2].Value.ToString()));
                                writer.Write(int.Parse(Arbol.Rows[row].Cells[3].Value.ToString()));
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[4].Value.ToString()));
                                writer.Write(int.Parse(Arbol.Rows[row].Cells[5].Value.ToString()));
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[6].Value.ToString()));
                                writer.Write(int.Parse(Arbol.Rows[row].Cells[7].Value.ToString()));
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[8].Value.ToString()));
                                writer.Write(int.Parse(Arbol.Rows[row].Cells[9].Value.ToString()));
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[10].Value.ToString()));
                            }
                            else {
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[0].Value.ToString()));
                                writer.Write(int.Parse(Arbol.Rows[row].Cells[3].Value.ToString()));
                                nums.Add(int.Parse(Arbol.Rows[row].Cells[3].Value.ToString()));
                                writer.Write(Arbol.Rows[row].Cells[1].Value.ToString());
                                writer.Write(long.Parse(Arbol.Rows[row].Cells[2].Value.ToString()));
                            }
                        }
                        nums.Add(-1);
                        
                        fs.Seek(100, SeekOrigin.Begin);
                        for (int i = 0; i < nums.Count ; i++)
                        {
                            writer.Write(nums[i]);
                        }
                        writer.Flush();
                        }
                }
            }
        }
        public void LeerDatos(object sender, EventArgs e,string filePath)
        {
            FileStream fs = new FileStream(filePath, FileMode.Open);
            using (BinaryReader reader = new BinaryReader(fs))
            {
                int ultimoDatoLeido = -2;
                fs.Seek(100, SeekOrigin.Begin);
                while (ultimoDatoLeido != -1 && ultimoDatoLeido!=0)
                {
                    
                    ultimoDatoLeido = reader.ReadInt32();
                    if (ultimoDatoLeido <= 0) {
                        break;
                            }
                    Numero.Text = ultimoDatoLeido.ToString();
                    btnInserta_Click(sender,e);
                }
            }
        }

        private void btnAbrirBin_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Archivos binarios (*.bin)|*.bin";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                
                string fileName = ofd.FileName;
                
                LeerDatos(sender,e,fileName);
            }
        }

        private void btnInserta_Click(object sender, EventArgs e)
        {
             int aux = 0;
            
            if (file == null)
            {
                MessageBox.Show("Nombre a su archivo");
                inseetFlag = true;
                nuevoFile(sender, e);

            }

            if (Numero.TextLength > 0)
            {
                int.TryParse(Numero.Text, out aux);
                if (aux <= 0)
                {
                    MessageBox.Show("Ingrese un digito");

                }
                else
                {
                    nuevoDato(aux);
                    EndOfFile.Text = "" + tam;
                    Numero.Clear();
                }
            }
            else
            {
                MessageBox.Show("ERROR");
            }
        }

        private void Numero_KeyDown(object sender, KeyEventArgs e)
        {
            
                if (e.KeyCode == Keys.Enter)
                {

                btnInserta_Click(sender,e);
                    e.SuppressKeyPress = true;
                }
        }

   
        
    }

}






