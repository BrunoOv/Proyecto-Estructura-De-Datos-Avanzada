﻿namespace EditordeGrafos
{
    partial class Euler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelRecorridoMain = new System.Windows.Forms.Label();
            this.labelRecorrido = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelRecorridoMain
            // 
            this.labelRecorridoMain.AutoSize = true;
            this.labelRecorridoMain.Location = new System.Drawing.Point(12, 83);
            this.labelRecorridoMain.Name = "labelRecorridoMain";
            this.labelRecorridoMain.Size = new System.Drawing.Size(13, 13);
            this.labelRecorridoMain.TabIndex = 1;
            this.labelRecorridoMain.Text = "..";
            // 
            // labelRecorrido
            // 
            this.labelRecorrido.AutoSize = true;
            this.labelRecorrido.Location = new System.Drawing.Point(12, 50);
            this.labelRecorrido.Name = "labelRecorrido";
            this.labelRecorrido.Size = new System.Drawing.Size(13, 13);
            this.labelRecorrido.TabIndex = 2;
            this.labelRecorrido.Text = "..";
            // 
            // Euler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 120);
            this.Controls.Add(this.labelRecorrido);
            this.Controls.Add(this.labelRecorridoMain);
            this.Name = "Euler";
            this.Text = "Euler";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelRecorridoMain;
        private System.Windows.Forms.Label labelRecorrido;
    }
}