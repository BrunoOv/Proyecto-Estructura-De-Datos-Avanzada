﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditordeGrafos
{
    public class IntMed
    {
        public List<long> list_TreeContent;

        public IntMed()
        { }
    }
}
