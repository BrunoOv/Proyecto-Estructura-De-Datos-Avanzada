﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace EditordeGrafos
{
    public partial class RecorridoAmplitud : Form
    {
        NodeP raizActual = null;
        Graph grafo = null;
        public string name;
        public RecorridoAmplitud(Graph graph)
        {
            grafo = graph;
            InitializeComponent();
            Raices(grafo);
            comboBoxRaiz.SelectedIndexChanged += comboBoxRaiz_SelectedIndexChanged;

        }
        //Obtenemos todos los nodos del grafo para meterlos al combobox 
        public void Raices(Graph graph)
        {
            for (int i = 0; i < graph.Count; i++)
            {
                comboBoxRaiz.Items.Add(graph[i].Name);
            }
        }
        //Cuando se seleccione una raiz empieza el recorrido apartir de esa raiz
        public void comboBoxRaiz_SelectedIndexChanged(object sender, EventArgs e)
        {
            raizActual = grafo.ElementAt(comboBoxRaiz.SelectedIndex);
            RecorridaAmplitudBosque(grafo, raizActual);
        }

        //Recorrido En Amplitud
        public void RecorridaAmplitudBosque(Graph grafo, NodeP raizActual)
        {
            List<NodeP> Visitados = new List<NodeP>();
            Queue<NodeP> cola= new Queue<NodeP>();
            List<NodeP> raicesPosibles = new List<NodeP>(grafo); // Copiamos los nodos del grafo para manejarlos como posibles raíces por si no se comunican algunos nodos
            RecorridoPrintf.Text = "";

            /*BOSQUE*/
            while (raicesPosibles.Count > 0)
            {
                Visitados.Add(raizActual); // Agregamos la raíz a los visitados
                cola.Enqueue(raizActual); // Agregamos la raíz a la cola
                RecorridoPrintf.Text += "Raiz(" + raizActual.Name + ") ";// Imprimimos la raiz donde empezamos
            
                /*ARBOL*/
                while (cola.Count > 0)//Mientras nuestra cola tenga nodos 
                {
                    NodeP nodoActual = cola.Dequeue(); // Lo sacamos de la cola, sería nuestro nodo actual
   
                    /*Ordenamos los nodos relacionados,el metodo lo implemente en nodoP*/
                    nodoActual.OrdenaRelacion(nodoActual);
                    foreach (NodeR relacion in nodoActual.relations)//recorremos los nodos relacionados con el nodo actual osea los nodos de alado o que podemos llegar a ellos
                    {
                        NodeP nodoVecino = relacion.Up;
                        if (!Visitados.Contains(nodoVecino))//Checamos si ya fue visitado
                        {
                            cola.Enqueue(nodoVecino);//entra ala cola
                            Visitados.Add(nodoVecino);//y agregamos a que lo visitamos
                            RecorridoPrintf.Text += nodoVecino.Name + " "; //imprimimos nodo
                        }
                    }
                   
                }
                RecorridoPrintf.Text += "\n";
                    if (raicesPosibles.Count > 0)//Checamos si todos los nodos ya fueron visitados
                    {
                        for (int i = 0; i < Visitados.Count; i++)//vaciamos las raices visitadas
                        {
                            raicesPosibles.Remove(Visitados[i]);
                        }
                        if (raicesPosibles.Count > 0)
                        {
                            raizActual = raicesPosibles.First();//Nos movemos al siguiente nodo que no a sido visitado ni fue posible llegar a el
                        }
                    }
             }
        }
    }
}
