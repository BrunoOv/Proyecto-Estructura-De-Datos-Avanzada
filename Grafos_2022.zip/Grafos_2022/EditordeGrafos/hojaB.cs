﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EditordeGrafos
{
    public class hojaB
    {
        public List<long> elementos;
        public List<long> direcciones;
        public int aux_Cuenta;
        public long dir;
        public char tipo;
        public long grado;


        public hojaB(int g)
        {
            grado = g;
            direcciones = new List<long>();
            elementos = new List<long>();
        }
    }
}
